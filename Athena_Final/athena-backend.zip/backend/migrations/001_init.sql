-- Athena canonical schema. Every business table is scoped by org_id (tenant isolation).
CREATE TABLE organizations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
);

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER NOT NULL REFERENCES organizations(id),
    username TEXT NOT NULL,
    username_lower TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    created_at TEXT NOT NULL,
    last_login_at TEXT
);

-- Server-side sessions: only a SHA-256 of the token is stored, so a DB leak cannot be replayed.
CREATE TABLE sessions (
    token_hash TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL,
    expires_at TEXT NOT NULL
);

-- source: sample_seed | user_import | user_entry   (drives provenance labels)
CREATE TABLE products (
    org_id INTEGER NOT NULL REFERENCES organizations(id),
    sku TEXT NOT NULL,
    name TEXT NOT NULL,
    category TEXT,
    selling_price REAL,
    unit_cost REAL,
    margin_pct REAL,            -- net margin % after COGS and fees, as supplied
    source TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (org_id, sku)
);

CREATE TABLE campaigns (
    org_id INTEGER NOT NULL REFERENCES organizations(id),
    campaign_id TEXT NOT NULL,
    name TEXT NOT NULL,
    channel TEXT NOT NULL,
    sku TEXT,
    source TEXT NOT NULL,
    PRIMARY KEY (org_id, campaign_id)
);

CREATE TABLE campaign_daily (
    org_id INTEGER NOT NULL,
    day TEXT NOT NULL,
    campaign_id TEXT NOT NULL,
    spend REAL NOT NULL,
    revenue REAL NOT NULL,
    clicks INTEGER,
    conversions INTEGER,
    source TEXT NOT NULL,
    PRIMARY KEY (org_id, day, campaign_id),
    FOREIGN KEY (org_id, campaign_id) REFERENCES campaigns(org_id, campaign_id)
);
CREATE INDEX idx_campaign_daily_org_day ON campaign_daily(org_id, day);

CREATE TABLE inventory (
    org_id INTEGER NOT NULL,
    sku TEXT NOT NULL,
    stock_level INTEGER NOT NULL CHECK (stock_level >= 0),
    reserved INTEGER,
    source TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    PRIMARY KEY (org_id, sku),
    FOREIGN KEY (org_id, sku) REFERENCES products(org_id, sku)
);

-- Alerts are generated from data on demand; only the acknowledgement is stored.
CREATE TABLE alert_ack (
    org_id INTEGER NOT NULL,
    code TEXT NOT NULL,
    user_id INTEGER NOT NULL,
    acknowledged_at TEXT NOT NULL,
    PRIMARY KEY (org_id, code)
);

CREATE TABLE analysis_runs (
    id TEXT PRIMARY KEY,
    org_id INTEGER NOT NULL REFERENCES organizations(id),
    user_id INTEGER NOT NULL REFERENCES users(id),
    created_at TEXT NOT NULL,
    title TEXT NOT NULL,
    status TEXT NOT NULL,
    horizon_days INTEGER NOT NULL,
    headline TEXT NOT NULL,
    top_action TEXT,
    confidence_level TEXT,
    item_count INTEGER NOT NULL,
    skus_json TEXT NOT NULL,
    sources_json TEXT NOT NULL,
    input_json TEXT NOT NULL,
    result_json TEXT NOT NULL,   -- full frozen result: what Athena said, and the data it used, at that time
    engine_version TEXT NOT NULL
);
CREATE INDEX idx_runs_org_created ON analysis_runs(org_id, created_at DESC);

CREATE TABLE audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    org_id INTEGER,
    user_id INTEGER,
    ts TEXT NOT NULL,
    action TEXT NOT NULL,
    detail TEXT NOT NULL,
    ip TEXT
);
CREATE INDEX idx_audit_org_ts ON audit_log(org_id, id DESC);

-- Registry of preserved legacy datasets (the MySQL dump). Read-only source material.
CREATE TABLE legacy_datasets (
    table_name TEXT PRIMARY KEY,
    row_count INTEGER NOT NULL,
    columns_json TEXT NOT NULL,
    imported_at TEXT NOT NULL,
    origin TEXT NOT NULL
);
