import json

from .conftest import PW


def test_dashboard_and_campaign_decisions(client, make_user):
    h, _ = make_user()
    d = client.get("/api/dashboard?range=qtd", headers=h).json()
    assert d["data_status"]["has_data"] is True
    kinds = {k["metric"]: k for k in d["kpis"]}
    assert set(kinds) == {"ad_spend", "gross_revenue", "blended_roas", "net_contribution"}
    roas = kinds["blended_roas"]
    assert roas["type"] == "DERIVED" and roas["formula"] == "revenue / advertising_spend" and "campaign_daily.revenue" in roas["sources"]
    assert len(d["trajectory"]["x"]) == len(d["trajectory"]["series"][0]["values"]) > 5
    assert client.get("/api/dashboard?range=bogus", headers=h).status_code == 400
    camps = {c["campaign_id"]: c for c in client.get("/api/campaigns?range=30d", headers=h).json()["items"]}
    assert camps["CMP005"]["decision"]["action"] in ("PAUSE", "REDUCE")           # ROAS 0.9, 11% margin, 12 units
    assert camps["CMP001"]["decision"]["action"] in ("PAUSE", "REDUCE")           # ROAS 0.55, 8% margin
    assert camps["CMP002"]["decision"]["action"] in ("HOLD", "SCALE", "REVIEW")
    for c in camps.values():
        assert c["decision"]["evidence"] and c["decision"]["rationale"]


def test_alerts_generated_from_data_and_acknowledge(client, make_user):
    h, _ = make_user()
    a = client.get("/api/alerts", headers=h).json()["items"]
    cats = {x["category"] for x in a}
    assert "critical_inventory" in cats and "low_roas" in cats
    inv = [x for x in a if x["category"] == "critical_inventory"]
    assert {x["sku"] for x in inv} == {"SKU-002", "SKU-004"}                       # 12 and 23 units, threshold 30
    code = inv[0]["code"]
    assert client.post(f"/api/alerts/{code}/acknowledge", headers=h).json()["acknowledged"] is True
    assert client.post(f"/api/alerts/{code}/acknowledge", headers=h).json()["acknowledged"] is False
    assert client.post("/api/alerts/nope:nope/acknowledge", headers=h).status_code == 404


def test_custom_analysis_full_flow(client, make_user):
    h, signup = make_user()
    body = {"title": "Hoodie restock", "horizon_days": 30, "items": [{
        "sku": "SKU-001", "current_inventory": 150, "planned_inventory": 400, "selling_price": 1999, "unit_cost": 900,
        "expected_daily_demand": 8, "planned_ad_spend": 12000}]}
    r = client.post("/api/analysis", json=body, headers=h)
    assert r.status_code == 201, r.text
    res = r.json()
    it = res["items"][0]
    inp = {i["field"]: i for i in it["inputs"]}
    assert inp["selling_price"]["type"] == "ASSUMED" and inp["current_inventory"]["type"] == "ASSUMED"
    assert inp["margin_pct"]["type"] == "DERIVED"                                    # price & cost supplied -> derived margin
    m = {x["metric"]: x for x in it["projection"]["metrics"]}
    assert m["procurement_cost"]["value"] == 250 * 900 and m["procurement_cost"]["type"] == "DERIVED"
    assert m["projected_revenue"]["value"] == 30 * 8 * 1999 and m["projected_revenue"]["type"] == "FORECAST"
    assert m["cogs"]["value"] == 240 * 900
    assert m["projected_expenses"]["value"] == 12000 + 250 * 900
    assert m["projected_profit"]["value"] == 240 * 1999 - 240 * 900 - 12000
    assert m["ad_attributed_revenue"]["low"] <= m["ad_attributed_revenue"]["value"] <= m["ad_attributed_revenue"]["high"]
    perf = {x["metric"]: x for x in it["performance"]["metrics"]}
    assert perf["roas_30d"]["type"] == "DERIVED" and perf["ad_spend_30d"]["type"] == "OBSERVED"
    assert it["decision"]["action"] in {"SCALE", "HOLD", "REDUCE", "PAUSE", "REVIEW"} and it["decision"]["evidence"]
    assert it["inventory"]["days_of_cover"] == 50.0
    for q in ("what_happened", "why_it_happened", "data_support", "prediction", "recommended_action", "why_recommended"):
        assert q in it["explanation"]
    assert any(c["type"] == "trajectory" for c in it["charts"])
    refs = {r["key"] for r in res["references"]}
    assert {"campaign_daily.spend", "campaign_daily.revenue", "user_input.selling_price", "method.decision_rules"} <= refs
    sample = [r for r in res["references"] if r["key"] == "campaign_daily.spend"][0]
    assert any("synthetic" in lbl.lower() for lbl in sample["origin_labels"]) and sample["time_range"]
    # history persistence
    hist = client.get("/api/history", headers=h).json()
    assert hist["total"] == 1 and hist["items"][0]["id"] == res["id"]
    card = hist["items"][0]
    assert card["decisions"][0]["sku"] == "SKU-001" and card["inventory_state"][0]["planned"] == 400 and card["user"] == signup["user"]["username"]
    assert card["data_sources"] and card["input_summary"][0]["sku"] == "SKU-001"
    again = client.get(f"/api/analysis/{res['id']}", headers=h).json()
    assert again == res                                                              # frozen result is identical later
    assert client.get("/api/references", params={"analysis_id": res["id"]}, headers=h).json()["references"] == res["references"]
    cc = client.get("/api/command-center", headers=h).json()
    assert [m["key"] for m in cc["modes"]] == ["history", "run_analysis", "references"] and cc["modes"][0]["count"] == 1


def test_no_fabrication_when_inputs_are_missing(client, make_user):
    h, _ = make_user()
    r = client.post("/api/analysis", headers=h, json={"items": [{"sku": "NEW-SKU", "current_inventory": 5}]}).json()
    it = r["items"][0]
    assert it["decision"]["action"] == "REVIEW" and it["campaign"] is None
    m = {x["metric"]: x["value"] for x in it["projection"]["metrics"]}
    assert m["projected_revenue"] is None and m["projected_profit"] is None and m["planned_ad_spend"] is None
    assert any("campaign" in g.lower() for g in it["data_gaps"]) and r["data_gaps"]
    assert it["decision"]["confidence"]["level"] == "LOW"
    assert {i["field"]: i["available"] for i in it["inputs"]}["selling_price"] is False


def test_stock_and_margin_logic_in_scenarios(client, make_user):
    h, _ = make_user()
    r = client.post("/api/analysis", headers=h, json={"items": [
        {"sku": "SKU-006", "planned_inventory": 0},                                    # strong campaign, no stock
        {"sku": "SKU-004"}]}).json()                                                   # weak margin, low stock
    a, b = r["items"]
    assert a["decision"]["action"] == "PAUSE" and "STOCK_OUT" in a["decision"]["reason_codes"]
    assert b["decision"]["action"] in ("PAUSE", "REDUCE") and any("margin" in x.lower() for x in b["decision"]["rationale"])
    assert r["summary"]["top_priority_action"] == "PAUSE" and len(r["allocation"]) == 2


def test_analysis_validation(client, make_user):
    h, _ = make_user()
    assert client.post("/api/analysis", headers=h, json={"items": []}).status_code == 422
    assert client.post("/api/analysis", headers=h, json={"items": [{"sku": "A", "current_inventory": -1}]}).status_code == 422
    assert client.post("/api/analysis", headers=h, json={"items": [{"sku": "A", "planned_ad_spend": 1, "planned_daily_spend": 1}]}).status_code == 422
    assert client.post("/api/analysis", headers=h, json={"items": [{"sku": "A"}, {"sku": "a"}]}).status_code == 422
    assert client.post("/api/analysis", headers=h, json={"items": [{"sku": "SKU-001", "campaign_id": "NOPE"}]}).status_code == 422
    assert client.post("/api/analysis", headers=h, json={"horizon_days": 0, "items": [{"sku": "A"}]}).status_code == 422


def test_tenant_isolation(client, make_user):
    ha, _ = make_user()
    hb, _ = make_user(sample=False)
    rid = client.post("/api/analysis", headers=ha, json={"items": [{"sku": "SKU-001"}]}).json()["id"]
    assert client.get(f"/api/analysis/{rid}", headers=hb).status_code == 404
    assert client.get("/api/references", params={"analysis_id": rid}, headers=hb).status_code == 404
    assert client.get("/api/history", headers=hb).json()["total"] == 0
    d = client.get("/api/dashboard", headers=hb).json()
    assert d["data_status"]["has_data"] is False and d["kpis"] == []
    assert client.get("/api/inventory", headers=hb).json()["items"] == []
    # B's analysis of A's SKU finds nothing: no leakage of A's campaigns
    r = client.post("/api/analysis", headers=hb, json={"items": [{"sku": "SKU-001"}]}).json()
    assert r["items"][0]["campaign"] is None and r["items"][0]["decision"]["action"] == "REVIEW"


def test_inventory_upsert_and_import(client, make_user):
    h, _ = make_user(sample=False)
    assert client.post("/api/inventory", headers=h, json={"sku": "N1", "stock_level": 5}).status_code == 422   # new SKU needs a name
    r = client.post("/api/inventory", headers=h, json={"sku": "N1", "stock_level": 5, "product_name": "Thing", "selling_price": 100, "unit_cost": 40})
    assert r.status_code == 201 and r.json()["stock_status"] == "LOW" and r.json()["source"] == "user_entry"
    assert client.post("/api/inventory", headers=h, json={"sku": "N1", "stock_level": 500}).json()["stock_status"] == "OK"
    assert client.post("/api/import/campaigns", headers=h, json={"csv": "campaign_id,name,channel,sku\nC1,Camp,Meta,NOPE\n"}).status_code == 400
    assert client.post("/api/import/campaigns", headers=h, json={"csv": "campaign_id,name,channel,sku\nC1,Camp,Meta,N1\n"}).json()["imported"] == 1
    daily = "day,campaign_id,spend,revenue\n" + "\n".join(f"2026-09-{d:02d},C1,100,{300 + d}" for d in range(1, 21))
    assert client.post("/api/import/daily", headers=h, json={"csv": daily}).json()["imported"] == 20
    assert client.post("/api/import/daily", headers=h, json={"csv": "day,campaign_id,spend,revenue\nbad-date,C1,1,1"}).status_code == 400
    assert client.post("/api/import/daily", headers=h, json={"csv": "day,campaign_id,spend,revenue\n2026-09-01,C1,-5,1"}).status_code == 400
    d = client.get("/api/dashboard?range=30d", headers=h).json()
    assert d["data_status"]["has_data"] and d["kpis"][0]["value"] == 2000
    ex = client.get("/api/export/daily", headers=h)
    assert ex.text.splitlines()[0] == "day,campaign_id,spend,revenue,clicks,conversions" and len(ex.text.splitlines()) == 21
    assert client.get("/api/audit", headers=h).json()["items"][0]["action"] in {"data_import", "inventory_update"}


def test_remove_sample_keeps_user_data(client, make_user):
    h, _ = make_user()
    client.post("/api/inventory", headers=h, json={"sku": "MINE", "stock_level": 9, "product_name": "Mine"})
    out = client.delete("/api/data/sample", headers=h).json()["removed"]
    assert out["campaign_daily"] > 1000
    items = client.get("/api/inventory", headers=h).json()["items"]
    assert [i["sku"] for i in items] == ["MINE"]


def test_references_catalog_and_legacy_preservation(client, make_user):
    h, _ = make_user()
    r = client.get("/api/references", headers=h).json()
    legacy = {d["name"]: d for d in r["datasets"] if d["scope"] == "legacy"}
    assert len(legacy) == 23 and legacy["legacy_advertising_campaigns_result"]["rows"] == 596
    fc = legacy["legacy_revenu_prediction_for_30_days"]
    assert fc["used_in_analysis"] is False and "not linked" in fc["usage_note"] and fc["rows"] == 30
    org = {d["name"]: d for d in r["datasets"] if d["scope"] == "organization"}
    assert org["campaign_daily"]["rows"] == 190 * 6 and org["campaign_daily"]["origin"] == ["sample_seed"]
    keys = {x["key"] for x in r["references"]}
    assert "campaign_daily.spend" in keys and "method.linear_trend_forecast" in keys
    entry = [x for x in r["references"] if x["key"] == "campaign_daily.spend"][0]
    for f in ("source", "table", "field", "purpose", "transformation", "reason", "limitations", "origin_labels"):
        assert entry[f]


def test_insights_reallocation_respects_stock(client, make_user):
    h, _ = make_user()
    ins = client.get("/api/insights?range=qtd", headers=h).json()
    assert ins["items"] and all(i["evidence"] for i in ins["items"])
    plan = ins["reallocation"]
    assert plan["items"] and abs(sum(i["change"] for i in plan["items"])) < 1.0     # budget-neutral
    low_stock = {"CMP001", "CMP005"}                                                  # SKU-004 / SKU-002 are low on stock
    assert all(i["change"] <= 0 for i in plan["items"] if i["campaign_id"] in low_stock)


def test_health(client):
    assert client.get("/health").json()["status"] == "ok"
