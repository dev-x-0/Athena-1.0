from app.security import hash_password, verify_password

from .conftest import PW


def test_password_hashing_is_salted_and_verifies():
    a, b = hash_password(PW), hash_password(PW)
    assert a != b and PW not in a and a.startswith("scrypt$")
    assert verify_password(PW, a) and not verify_password("wrong", a)


def test_signup_validation(client):
    assert client.post("/auth/signup", json={"username": "ab", "password": PW}).status_code == 422
    assert client.post("/auth/signup", json={"username": "good_name", "password": "short1"}).status_code == 422
    assert client.post("/auth/signup", json={"username": "good_name", "password": "onlyletters"}).status_code == 422
    assert client.post("/auth/signup", json={"username": "bad name!", "password": PW}).status_code == 422


def test_signup_login_me_logout(client):
    r = client.post("/auth/signup", json={"username": "Alice_A", "password": PW})
    assert r.status_code == 201 and "athena_session" in r.headers["set-cookie"] and "HttpOnly" in r.headers["set-cookie"]
    assert client.post("/auth/signup", json={"username": "alice_a", "password": PW}).status_code == 409  # case-insensitive
    client.cookies.clear()
    assert client.get("/auth/me").status_code == 401
    assert client.post("/auth/login", json={"username": "alice_a", "password": "nope-nope1"}).status_code == 401
    r = client.post("/auth/login", json={"username": "ALICE_A", "password": PW})
    assert r.status_code == 200
    token = r.json()["token"]
    assert client.get("/auth/me").json()["user"]["username"] == "Alice_A"  # cookie auth
    client.cookies.clear()
    assert client.get("/auth/me", headers={"Authorization": f"Bearer {token}"}).status_code == 200  # bearer auth
    assert client.post("/auth/logout", headers={"Authorization": f"Bearer {token}"}).status_code == 200
    assert client.get("/auth/me", headers={"Authorization": f"Bearer {token}"}).status_code == 401
    client.cookies.clear()


def test_endpoints_require_auth(client):
    client.cookies.clear()
    for path in ("/api/dashboard", "/api/history", "/api/references", "/api/inventory", "/api/campaigns", "/api/command-center"):
        assert client.get(path).status_code == 401, path
    assert client.post("/api/analysis", json={"items": [{"sku": "X"}]}).status_code == 401


def test_login_throttle(client):
    client.post("/auth/signup", json={"username": "throttled", "password": PW})
    client.cookies.clear()
    for _ in range(5):
        assert client.post("/auth/login", json={"username": "throttled", "password": "bad-pass1"}).status_code == 401
    assert client.post("/auth/login", json={"username": "throttled", "password": PW}).status_code == 429
