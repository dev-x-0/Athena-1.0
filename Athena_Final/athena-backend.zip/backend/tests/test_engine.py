from datetime import date, timedelta

from app.engine import decision as D
from app.engine.forecast import linear_forecast

BASE = dict(has_campaign=True, data_days=30, roas=3.0, roas_floor=1.5, break_even_roas=2.0, roas_trend_pct=0.0, margin_pct=50.0,
            stock_units=200, days_of_cover=None, low_stock=30, planned_spend=None, baseline_spend=10000, max_useful_spend=None, forecast_change_pct=0.0)


def ev(**kw):
    return {**BASE, **kw}


def test_scale_requires_margin_headroom_and_healthy_stock():
    assert D.decide(ev())["action"] == "SCALE"
    assert D.decide(ev(roas=2.2))["action"] == "HOLD"                      # above break-even but no headroom
    assert D.decide(ev(margin_pct=10, break_even_roas=10, roas=3))["action"] in ("REDUCE", "PAUSE")


def test_revenue_growth_with_weak_margin_never_scales():
    d = D.decide(ev(margin_pct=10, break_even_roas=10, roas=12))           # ROAS clears break-even but margin is weak
    assert d["action"] == "HOLD" and d["reason_codes"] == ["WEAK_MARGIN"]
    assert any("margin" in c for c in d["conflicts"])


def test_critical_stock_blocks_scaling_and_explains_conflict():
    d = D.decide(ev(stock_units=12))
    assert d["action"] == "HOLD" and any("stock" in c.lower() for c in d["conflicts"])
    assert D.decide(ev(stock_units=0))["action"] == "PAUSE"
    assert D.decide(ev(days_of_cover=3.0, stock_units=500))["action"] == "HOLD"


def test_spend_beyond_stock_is_reduced_to_supported_level():
    d = D.decide(ev(planned_spend=20000, max_useful_spend=10000))
    assert d["action"] == "REDUCE" and d["spend_change_pct"] == -50


def test_deterioration_conflict_goes_to_review():
    d = D.decide(ev(roas_trend_pct=-35))
    assert d["action"] == "REVIEW" and d["conflicts"]


def test_unknown_margin_cannot_scale_and_no_data_is_review():
    assert D.decide(ev(margin_pct=None, break_even_roas=None))["action"] == "HOLD"
    d = D.decide(ev(has_campaign=False, roas=None))
    assert d["action"] == "REVIEW" and d["reason_codes"] == ["INSUFFICIENT_EVIDENCE"]
    assert D.decide(ev(data_days=3))["action"] == "REVIEW"


def test_below_floor_reduces_and_far_below_break_even_pauses():
    assert D.decide(ev(roas=1.0, break_even_roas=None, margin_pct=None))["action"] == "REDUCE"
    assert D.decide(ev(roas=0.5, break_even_roas=5.0, margin_pct=20))["action"] == "PAUSE"


def test_confidence_is_low_without_evidence():
    c = D.confidence(data_days=0, margin_known=False, weekly_cv=None, demand_known=False, price_known=False, has_campaign=False)
    assert c["level"] == "LOW" and "not a statistical probability" in c["basis"]


def _series(n, f):
    start = date(2026, 1, 1)
    return [{"day": (start + timedelta(days=i)).isoformat(), "value": f(i)} for i in range(n)]


def test_linear_forecast_exact_on_a_line_and_refuses_thin_data():
    fc = linear_forecast(_series(30, lambda i: 100 + 2 * i), 5)
    assert fc["base"][0] == 160.0 and fc["base"][4] == 168.0 and fc["r2"] == 1.0
    assert fc["total"]["low"] <= fc["total"]["base"] <= fc["total"]["high"]
    assert linear_forecast(_series(10, lambda i: i), 5) is None


def test_forecast_uses_real_day_offsets_when_days_missing():
    s = [x for x in _series(40, lambda i: 10 + i) if int(x["day"][-2:]) % 2 == 0 or True]
    s = s[::2]  # every other day -> slope per calendar day stays 0.5 per index step => 1 per 2 days
    fc = linear_forecast(s, 1, window_days=40, min_points=10)
    assert abs(fc["slope_per_day"] - 1.0) < 1e-6


def test_near_break_even_holds_instead_of_cutting():
    d = D.decide(ev(roas=1.95, break_even_roas=2.0, margin_pct=50))
    assert d["action"] == "HOLD" and d["reason_codes"] == ["NEAR_BREAK_EVEN"]


def test_stock_running_out_within_horizon_blocks_scale():
    d = D.decide(ev(days_of_cover=15.5, horizon_days=30))
    assert d["action"] == "HOLD" and d["reason_codes"] == ["STOCK_RUNS_OUT_IN_HORIZON"] and d["conflicts"]


def test_already_far_above_run_rate_does_not_scale_further():
    d = D.decide(ev(planned_spend=40000, baseline_spend=10000))
    assert d["action"] == "HOLD" and d["reason_codes"] == ["ALREADY_ABOVE_RUN_RATE"]


def test_noise_forecast_is_not_significant():
    import random
    from app.engine.forecast import differs_from_trailing
    rnd = random.Random(1)
    s = _series(30, lambda i: 1000 * rnd.uniform(0.8, 1.2))
    fc = linear_forecast(s, 7)
    assert not differs_from_trailing(fc, sum(x["value"] for x in s[-7:]))
