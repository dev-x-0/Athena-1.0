import os
import tempfile
from pathlib import Path

import pytest

_tmp = tempfile.mkdtemp(prefix="athena-test-")
os.environ["ATHENA_DB_PATH"] = str(Path(_tmp) / "test.db")
os.environ["ATHENA_LEGACY_DUMP"] = str(Path(__file__).resolve().parent.parent / "data" / "legacy" / "athena.sql")

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402
from app.security import throttle  # noqa: E402

PW = "Sup3rSecret!"


@pytest.fixture(scope="session")
def client():
    with TestClient(app) as c:
        yield c


@pytest.fixture()
def make_user(client):
    """Factory: creates an isolated org + returns (headers, signup_json)."""
    counter = {"n": 0}

    def _make(sample=True, name=None):
        counter["n"] += 1
        uname = name or f"user{counter['n']}_{os.urandom(3).hex()}"
        r = client.post("/auth/signup", json={"username": uname, "password": PW, "load_sample_data": sample})
        assert r.status_code == 201, r.text
        body = r.json()
        client.cookies.clear()
        return {"Authorization": f"Bearer {body['token']}"}, body

    return _make


@pytest.fixture(autouse=True)
def _reset_throttle():
    throttle.clear()
    yield
