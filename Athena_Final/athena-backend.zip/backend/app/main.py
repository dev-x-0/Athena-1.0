"""Athena API entrypoint.  Run:  uvicorn app.main:app --reload"""
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .config import ENGINE_VERSION, settings
from .db import connect, migrate, one
from .legacy_import import import_dump
from .routers import analysis, auth, data, imports, references


@asynccontextmanager
async def lifespan(app: FastAPI):
    conn = connect()
    try:
        migrate(conn)
        dump = Path(settings().legacy_dump)
        if dump.exists() and one(conn, "SELECT COUNT(*) AS n FROM legacy_datasets")["n"] == 0:
            import_dump(conn, dump)
    finally:
        conn.close()
    yield


def create_app() -> FastAPI:
    app = FastAPI(title="Athena API", version="1.0.0", lifespan=lifespan,
                  description="Autonomous advertising and business-intelligence decision engine.")
    app.add_middleware(CORSMiddleware, allow_origins=settings().cors_origins, allow_credentials=True,
                       allow_methods=["*"], allow_headers=["*"])
    for r in (auth.router, data.router, analysis.router, references.router, imports.router):
        app.include_router(r)

    @app.get("/health", tags=["meta"])
    def health():
        return {"status": "ok", "service": "athena", "engine_version": ENGINE_VERSION}

    return app


app = create_app()
