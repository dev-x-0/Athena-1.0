"""Preserve the MySQL dump (UTF-16 mysqldump) as read-only legacy_* tables in the canonical DB.

Nothing is merged into org data: the legacy tables are public/third-party style datasets whose
keys and scales do not line up with campaign_daily. They stay available for the references screen.
Run manually:  python -m app.legacy_import [path/to/athena.sql]
"""
import json
import re
import sys
from pathlib import Path

from .config import settings
from .db import connect, migrate, now_iso, transaction

_CREATE = re.compile(r"CREATE TABLE `(\w+)` \((.*?)\)\s*ENGINE", re.S)
_INSERT = re.compile(r"INSERT INTO `(\w+)` VALUES ", re.I)


def read_dump(path) -> str:
    raw = Path(path).read_bytes()
    for enc in ("utf-16", "utf-8-sig", "latin-1"):
        try:
            text = raw.decode(enc)
            if "CREATE TABLE" in text:
                return text
        except UnicodeError:
            continue
    raise ValueError("Unrecognised dump encoding")


def parse_values(text: str, start: int):
    """Parse '(..),(..);' starting at `start`; returns (rows, end_index). Handles quotes and escapes."""
    rows, i, n = [], start, len(text)
    while i < n:
        while i < n and text[i] in " \r\n,":
            i += 1
        if i >= n or text[i] == ";":
            return rows, i + 1
        if text[i] != "(":
            raise ValueError(f"Unexpected character {text[i]!r} at {i}")
        i += 1
        row, cur, in_q, was_q = [], [], False, False
        while i < n:
            ch = text[i]
            if in_q:
                if ch == "\\" and i + 1 < n:
                    nxt = text[i + 1]
                    cur.append({"n": "\n", "r": "\r", "t": "\t", "0": "\0"}.get(nxt, nxt))
                    i += 2
                    continue
                if ch == "'":
                    if i + 1 < n and text[i + 1] == "'":
                        cur.append("'")
                        i += 2
                        continue
                    in_q = False
                else:
                    cur.append(ch)
            elif ch == "'":
                in_q = was_q = True
            elif ch in ",)":
                val = "".join(cur)
                row.append(val if was_q else (None if val.strip().upper() == "NULL" else val.strip()))
                cur, was_q = [], False
                if ch == ")":
                    i += 1
                    break
            else:
                cur.append(ch)
            i += 1
        rows.append(tuple(row))
    return rows, i


def import_dump(conn, path, force: bool = False) -> dict:
    text = read_dump(path)
    schemas = {m.group(1): re.findall(r"`(\w+)` ", m.group(2)) for m in _CREATE.finditer(text)}
    existing = {r[0] for r in conn.execute("SELECT table_name FROM legacy_datasets")}
    imported = {}
    with transaction(conn):
        for m in _INSERT.finditer(text):
            table = m.group(1)
            if table not in schemas or (table in existing and not force):
                continue
            rows, _ = parse_values(text, m.end())
            cols = schemas[table]
            if any(len(r) != len(cols) for r in rows):
                raise ValueError(f"Column count mismatch in {table}")
            name = f"legacy_{table}"
            conn.execute(f'DROP TABLE IF EXISTS "{name}"')
            conn.execute(f'CREATE TABLE "{name}" ({", ".join(f"{chr(34)}{c}{chr(34)} TEXT" for c in cols)})')
            conn.executemany(f'INSERT INTO "{name}" VALUES ({",".join("?" * len(cols))})', rows)
            conn.execute(
                "INSERT OR REPLACE INTO legacy_datasets VALUES (?,?,?,?,?)",
                (table, len(rows), json.dumps(cols), now_iso(), "legacy_dump"),
            )
            imported[table] = len(rows)
    return imported


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else settings().legacy_dump
    c = connect()
    migrate(c)
    print(import_dump(c, target, force=True))
