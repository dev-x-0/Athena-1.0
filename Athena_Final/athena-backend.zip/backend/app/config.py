"""Runtime configuration. Everything comes from environment variables (.env supported)."""
import os
from dataclasses import dataclass
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent.parent
load_dotenv(BACKEND_DIR / ".env")

ENGINE_VERSION = "athena-engine-1.0"


@dataclass(frozen=True)
class Settings:
    db_path: str
    session_ttl_hours: int
    cookie_secure: bool
    cors_origins: list
    roas_floor: float
    low_stock: int
    legacy_dump: str
    cookie_name: str = "athena_session"


def _bool(v: str) -> bool:
    return str(v).strip().lower() in {"1", "true", "yes", "on"}


def settings() -> Settings:
    """Built on every call so tests / deployments can change env vars."""
    e = os.environ.get
    origins = e("ATHENA_CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173")
    return Settings(
        db_path=e("ATHENA_DB_PATH", str(BACKEND_DIR / "data" / "athena.db")),
        session_ttl_hours=int(e("ATHENA_SESSION_TTL_HOURS", "168")),
        cookie_secure=_bool(e("ATHENA_COOKIE_SECURE", "false")),
        cors_origins=[o.strip() for o in origins.split(",") if o.strip()],
        roas_floor=float(e("ATHENA_ROAS_FLOOR", "1.5")),
        low_stock=int(e("ATHENA_LOW_STOCK_UNITS", "30")),
        legacy_dump=e("ATHENA_LEGACY_DUMP", str(BACKEND_DIR / "data" / "legacy" / "athena.sql")),
    )
