"""Password hashing (scrypt, stdlib), session tokens, input validation, login throttling."""
import base64
import hashlib
import hmac
import re
import secrets
import time

_N, _R, _P = 2**14, 8, 1
_USERNAME = re.compile(r"^[A-Za-z0-9_.-]{3,32}$")
_COMMON = {"password", "password1", "12345678", "123456789", "qwerty123", "letmein123", "athena123", "admin123"}


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    dk = hashlib.scrypt(password.encode(), salt=salt, n=_N, r=_R, p=_P, dklen=32)
    b = lambda x: base64.b64encode(x).decode()  # noqa: E731
    return f"scrypt${_N}${_R}${_P}${b(salt)}${b(dk)}"


def verify_password(password: str, stored: str) -> bool:
    try:
        _, n, r, p, salt, dk = stored.split("$")
        expect = base64.b64decode(dk)
        got = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt), n=int(n), r=int(r), p=int(p), dklen=len(expect))
        return hmac.compare_digest(got, expect)
    except Exception:
        return False


DUMMY_HASH = hash_password("athena-dummy-password-for-timing")  # equalises timing for unknown users


def new_token() -> str:
    return secrets.token_urlsafe(32)


def hash_token(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


def validate_username(username: str) -> str | None:
    if not _USERNAME.match(username or ""):
        return "Username must be 3-32 characters: letters, digits, '.', '_' or '-'."
    return None


def validate_password(password: str, username: str = "") -> str | None:
    if not password or len(password) < 8:
        return "Password must be at least 8 characters."
    if len(password) > 128:
        return "Password must be at most 128 characters."
    if not re.search(r"[A-Za-z]", password) or not re.search(r"\d", password):
        return "Password must contain at least one letter and one digit."
    if password.lower() == (username or "").lower() or password.lower() in _COMMON:
        return "Password is too easy to guess."
    return None


class LoginThrottle:
    """In-memory brute-force guard: 5 failures / 15 min per (username, ip). Single-process only."""

    def __init__(self, limit=5, window=900):
        self.limit, self.window, self.fails = limit, window, {}

    def _recent(self, key):
        cutoff = time.time() - self.window
        self.fails[key] = [t for t in self.fails.get(key, []) if t > cutoff]
        return self.fails[key]

    def blocked(self, key) -> bool:
        return len(self._recent(key)) >= self.limit

    def record_failure(self, key):
        self._recent(key).append(time.time())

    def clear(self, key=None):
        self.fails.pop(key, None) if key else self.fails.clear()


throttle = LoginThrottle()
