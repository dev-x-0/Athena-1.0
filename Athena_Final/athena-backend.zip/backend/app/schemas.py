"""Request models (validation). Response shapes are documented in API_CONTRACT.md."""
from pydantic import BaseModel, Field, field_validator, model_validator


class SignupIn(BaseModel):
    username: str = Field(min_length=3, max_length=32)
    password: str = Field(min_length=8, max_length=128)
    company_name: str | None = Field(None, max_length=80)
    load_sample_data: bool = True


class LoginIn(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=128)


class AnalysisItem(BaseModel):
    sku: str = Field(min_length=1, max_length=64)
    product_name: str | None = Field(None, max_length=120)
    current_inventory: int | None = Field(None, ge=0)
    planned_inventory: int | None = Field(None, ge=0)
    selling_price: float | None = Field(None, gt=0)
    unit_cost: float | None = Field(None, ge=0)
    margin_pct: float | None = Field(None, ge=-100, le=100)
    expected_daily_demand: float | None = Field(None, ge=0)
    campaign_id: str | None = Field(None, max_length=64)
    channel: str | None = Field(None, max_length=64)
    planned_ad_spend: float | None = Field(None, ge=0, description="Total spend over the horizon")
    planned_daily_spend: float | None = Field(None, ge=0)

    @field_validator("sku")
    @classmethod
    def _strip(cls, v):
        v = v.strip()
        if not v:
            raise ValueError("sku is required")
        return v

    @model_validator(mode="after")
    def _one_spend(self):
        if self.planned_ad_spend is not None and self.planned_daily_spend is not None:
            raise ValueError("Provide planned_ad_spend or planned_daily_spend, not both")
        return self


class Assumptions(BaseModel):
    roas_floor: float | None = Field(None, gt=0, le=100)
    notes: str | None = Field(None, max_length=500)


class AnalysisRequest(BaseModel):
    title: str | None = Field(None, max_length=120)
    horizon_days: int = Field(30, ge=1, le=180)
    items: list[AnalysisItem] = Field(min_length=1, max_length=25)
    assumptions: Assumptions | None = None

    @model_validator(mode="after")
    def _unique(self):
        skus = [i.sku.lower() for i in self.items]
        if len(skus) != len(set(skus)):
            raise ValueError("Each SKU may appear only once per analysis")
        return self


class InventoryIn(BaseModel):
    sku: str = Field(min_length=1, max_length=64)
    stock_level: int = Field(ge=0)
    reserved: int | None = Field(None, ge=0)
    product_name: str | None = Field(None, max_length=120, description="Required when the SKU is new")
    category: str | None = Field(None, max_length=60)
    selling_price: float | None = Field(None, gt=0)
    unit_cost: float | None = Field(None, ge=0)
    margin_pct: float | None = Field(None, ge=-100, le=100)


class CsvIn(BaseModel):
    csv: str = Field(max_length=5_000_000)
