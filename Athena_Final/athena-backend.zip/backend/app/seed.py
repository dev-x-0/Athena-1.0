"""Sample data for a new organisation.

This is SYNTHETIC demo data (deterministic generator carried over from the team's SQLite prototype).
Every row is tagged source='sample_seed' so provenance labels it honestly and it can be removed.
"""
import random
from datetime import date, timedelta

from .db import now_iso

HISTORY_DAYS = 190  # 90-day window + the 90 days before it for comparisons

# (sku, product_name, stock, net_margin_pct)
PRODUCTS = [
    ("SKU-001", "Heavyweight Hoodie", 150, 42.5),
    ("SKU-002", "Classic Cotton Tee", 12, 11.2),
    ("SKU-003", "Running Cap", 310, 48.0),
    ("SKU-004", "Linen Overshirt", 23, 8.4),
    ("SKU-005", "Merino Beanie", 84, 36.5),
    ("SKU-006", "Canvas Tote", 205, 29.0),
]
# (campaign_id, name, channel, sku, typical daily spend INR, typical ROAS, ROAS decay per day of age)
CAMPAIGNS = [
    ("CMP001", "Linen Overshirt Prospecting", "Meta", "SKU-004", 520, 0.55, 0.004),
    ("CMP002", "Hoodie Retargeting", "Meta", "SKU-001", 380, 2.60, 0.000),
    ("CMP003", "Running Cap Shopping", "Google Shopping", "SKU-003", 640, 2.10, -0.002),
    ("CMP004", "Brand Search", "Google Shopping", "SKU-005", 210, 3.20, 0.000),
    ("CMP005", "Creator Spark Ads", "TikTok", "SKU-002", 460, 0.90, 0.000),
    ("CMP006", "Email and Affiliate Flows", "Direct", "SKU-006", 135, 4.00, 0.000),
]
SRC = "sample_seed"


def seed_org(conn, org_id: int, today: date | None = None) -> None:
    """Insert sample data. Caller owns the transaction."""
    today, ts = today or date.today(), now_iso()
    conn.executemany(
        "INSERT INTO products (org_id, sku, name, margin_pct, source, updated_at) VALUES (?,?,?,?,?,?)",
        [(org_id, s, n, m, SRC, ts) for s, n, _, m in PRODUCTS],
    )
    conn.executemany(
        "INSERT INTO campaigns (org_id, campaign_id, name, channel, sku, source) VALUES (?,?,?,?,?,?)",
        [(org_id, c, n, ch, sku, SRC) for c, n, ch, sku, *_ in CAMPAIGNS],
    )
    conn.executemany(
        "INSERT INTO inventory (org_id, sku, stock_level, source, updated_at) VALUES (?,?,?,?,?)",
        [(org_id, s, st, SRC, ts) for s, _, st, _ in PRODUCTS],
    )
    rng, rows = random.Random(42), []
    for age in range(HISTORY_DAYS):
        day = (today - timedelta(days=age)).isoformat()
        for cid, _, _, _, spend, roas, decay in CAMPAIGNS:
            s = spend * rng.uniform(0.82, 1.18)
            r = s * roas * (1 + decay * age) * rng.uniform(0.8, 1.2)
            rows.append((org_id, day, cid, round(s, 2), round(r, 2), SRC))
    conn.executemany(
        "INSERT INTO campaign_daily (org_id, day, campaign_id, spend, revenue, source) VALUES (?,?,?,?,?,?)", rows
    )


def remove_sample(conn, org_id: int) -> dict:
    """Delete only rows tagged sample_seed (user data is never touched). Caller owns the transaction."""
    out = {}
    for t, extra in (("campaign_daily", ""), ("inventory", ""), ("campaigns", ""), ("products", "")):
        # children first; a sample product/campaign that user data still references is kept
        if t == "campaigns":
            extra = " AND campaign_id NOT IN (SELECT campaign_id FROM campaign_daily WHERE org_id=?)"
        if t == "products":
            extra = (" AND sku NOT IN (SELECT sku FROM inventory WHERE org_id=?)"
                     " AND sku NOT IN (SELECT sku FROM campaigns WHERE org_id=? AND sku IS NOT NULL)")
        n_extra = extra.count("?")
        cur = conn.execute(f"DELETE FROM {t} WHERE org_id=? AND source=?{extra}", (org_id, SRC, *([org_id] * n_extra)))
        out[t] = cur.rowcount
    return out
