import json
import uuid

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ..config import ENGINE_VERSION
from ..db import get_db, now_iso, one, rows, transaction
from ..deps import audit, current_user
from ..engine import scenario
from ..engine.provenance import ORIGIN_LABELS
from ..schemas import AnalysisRequest

router = APIRouter(tags=["analysis"])


def _data_sources(result: dict) -> list[dict]:
    seen = {}
    for r in result.get("references", []):
        if r["kind"] == "method":
            continue
        name = r["table"] or "user input"
        seen.setdefault(name, set()).update(r.get("origin_labels", []))
    return [{"source": k, "origin": sorted(v)} for k, v in sorted(seen.items())]


def history_card(row: dict, result: dict) -> dict:
    items = result.get("items", [])
    return {
        "id": row["id"], "created_at": row["created_at"], "title": row["title"], "status": row["status"],
        "user": row["username"], "company": row["org_name"], "horizon_days": row["horizon_days"],
        "headline": row["headline"], "top_action": row["top_action"], "confidence_level": row["confidence_level"],
        "item_count": row["item_count"], "skus": json.loads(row["skus_json"]), "data_sources": json.loads(row["sources_json"]),
        "input_summary": [{k: v for k, v in i.items() if k in ("sku", "current_inventory", "planned_inventory", "selling_price", "expected_daily_demand", "planned_ad_spend", "planned_daily_spend", "campaign_id")}
                          for i in (json.loads(row["input_json"]).get("items", []))],
        "inventory_state": [{"sku": i["sku"], "current": i["inventory"]["current"], "planned": i["inventory"]["planned"],
                             "days_of_cover": i["inventory"]["days_of_cover"], "risk": i["inventory"]["risk"]["level"]} for i in items],
        "major_metrics": result.get("summary", {}).get("kpis", []),
        "predictions": [{"sku": i["sku"], **{m["metric"]: m["value"] for m in i["projection"]["metrics"] if m["metric"] in ("ad_attributed_revenue", "projected_revenue", "projected_profit")}} for i in items],
        "decisions": [{"sku": i["sku"], "action": i["decision"]["action"], "spend_change_pct": i["decision"]["spend_change_pct"],
                       "confidence": i["decision"]["confidence"]["level"], "why": i["explanation"]["why_recommended"]} for i in items],
    }


@router.post("/api/analysis", status_code=201)
def run_analysis(body: AnalysisRequest, request: Request, user=Depends(current_user), db=Depends(get_db)):
    try:
        result = scenario.run(db, user["org_id"], body)
    except scenario.AnalysisInputError as e:
        raise HTTPException(422, str(e))
    rid, created = str(uuid.uuid4()), now_iso()
    title = (body.title or "").strip() or f"Analysis of {', '.join(i.sku for i in body.items[:3])}" + ("…" if len(body.items) > 3 else "")
    doc = {"id": rid, "created_at": created, "status": "completed", "title": title, "user": {"id": user["id"], "username": user["username"]},
           "company": {"id": user["org_id"], "name": user["org_name"]}, "input": body.model_dump(exclude_none=True), **result}
    s = result["summary"]
    with transaction(db):
        db.execute("INSERT INTO analysis_runs VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                   (rid, user["org_id"], user["id"], created, title, "completed", body.horizon_days, s["headline"], s["top_priority_action"],
                    s["confidence"]["level"], s["items_analyzed"], json.dumps([i.sku for i in body.items]), json.dumps(_data_sources(result)),
                    json.dumps(doc["input"]), json.dumps(doc), ENGINE_VERSION))
        audit(db, user, "analysis_run", f"{rid}: {s['headline']}", request)
    return doc


@router.get("/api/analysis/{analysis_id}")
def get_analysis(analysis_id: str, user=Depends(current_user), db=Depends(get_db)):
    row = one(db, "SELECT result_json FROM analysis_runs WHERE id=? AND org_id=?", (analysis_id, user["org_id"]))
    if not row:
        raise HTTPException(404, "Analysis not found")
    return json.loads(row["result_json"])


@router.get("/api/history")
def history(limit: int = Query(25, ge=1, le=100), offset: int = Query(0, ge=0), sku: str | None = None, action: str | None = None,
            user=Depends(current_user), db=Depends(get_db)):
    where, p = "r.org_id=?", [user["org_id"]]
    if sku:
        where += " AND r.skus_json LIKE ?"; p.append(f'%"{sku}"%')
    if action:
        where += " AND r.top_action=?"; p.append(action.upper())
    total = one(db, f"SELECT COUNT(*) AS n FROM analysis_runs r WHERE {where}", p)["n"]
    recs = rows(db, f"""SELECT r.*, u.username, o.name AS org_name FROM analysis_runs r JOIN users u ON u.id=r.user_id
                        JOIN organizations o ON o.id=r.org_id WHERE {where} ORDER BY r.created_at DESC, r.rowid DESC LIMIT ? OFFSET ?""", [*p, limit, offset])
    return {"total": total, "limit": limit, "offset": offset, "items": [history_card(r, json.loads(r["result_json"])) for r in recs]}
