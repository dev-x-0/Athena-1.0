"""CSV import/export of authorised business data (org-scoped, validated, audited)."""
import csv
import io
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request, Response

from ..db import get_db, now_iso, rows, transaction
from ..deps import audit, current_user
from ..schemas import CsvIn

router = APIRouter(tags=["import"])
MAX_ROWS = 50_000

# kind -> (table, columns, required, conflict key, optional columns kept when blank)
KINDS = {
    "products": ("products", ["sku", "name", "category", "selling_price", "unit_cost", "margin_pct"], ["sku", "name"], ["org_id", "sku"]),
    "campaigns": ("campaigns", ["campaign_id", "name", "channel", "sku"], ["campaign_id", "name", "channel"], ["org_id", "campaign_id"]),
    "daily": ("campaign_daily", ["day", "campaign_id", "spend", "revenue", "clicks", "conversions"], ["day", "campaign_id", "spend", "revenue"], ["org_id", "day", "campaign_id"]),
    "inventory": ("inventory", ["sku", "stock_level", "reserved"], ["sku", "stock_level"], ["org_id", "sku"]),
}
EXAMPLES = {"products": ["SKU-007", "Wool Scarf", "Accessories", 1499, 620, 38.5], "campaigns": ["CMP007", "Winter Launch", "Meta", "SKU-007"],
            "daily": ["2026-10-01", "CMP007", 1200, 3100, 410, 18], "inventory": ["SKU-007", 120, 8]}
DAY_FORMATS = ("%Y-%m-%d", "%d/%m/%Y", "%d-%m-%Y")


def _num(row, key, integer=False, required=False, low=0.0):
    raw = str(row.get(key) or "").strip().replace(",", "").replace("₹", "").replace("%", "")
    if not raw:
        if required:
            raise ValueError(f"{key} is required")
        return None
    try:
        v = float(raw)
    except ValueError:
        raise ValueError(f"{key} must be a number (got '{raw}')")
    if v < low:
        raise ValueError(f"{key} must be >= {low:g}")
    return int(v) if integer else v


def _text(row, key, required=False):
    v = str(row.get(key) or "").strip()
    if required and not v:
        raise ValueError(f"{key} is required")
    return v or None


def _day(v):
    for f in DAY_FORMATS:
        try:
            return datetime.strptime(v.strip(), f).date().isoformat()
        except ValueError:
            pass
    raise ValueError(f"unrecognised date '{v}' (use YYYY-MM-DD)")


def _clean(kind, row, known):
    if kind == "products":
        m = _num(row, "margin_pct", low=-100)
        if m is not None and m > 100:
            raise ValueError("margin_pct must be a percentage between -100 and 100")
        p = _num(row, "selling_price")
        if p is not None and p <= 0:
            raise ValueError("selling_price must be > 0")
        return [_text(row, "sku", True), _text(row, "name", True), _text(row, "category"), p, _num(row, "unit_cost"), m]
    if kind == "campaigns":
        sku = _text(row, "sku")
        if sku and sku not in known["skus"]:
            raise ValueError(f"unknown sku {sku}. Import products first")
        return [_text(row, "campaign_id", True), _text(row, "name", True), _text(row, "channel", True), sku]
    if kind == "daily":
        cid = _text(row, "campaign_id", True)
        if cid not in known["campaigns"]:
            raise ValueError(f"unknown campaign_id {cid}. Import campaigns first")
        return [_day(_text(row, "day", True)), cid, _num(row, "spend", required=True), _num(row, "revenue", required=True),
                _num(row, "clicks", True), _num(row, "conversions", True)]
    sku = _text(row, "sku", True)
    if sku not in known["skus"]:
        raise ValueError(f"unknown sku {sku}. Import products first")
    return [sku, _num(row, "stock_level", True, True), _num(row, "reserved", True)]


@router.get("/api/export/{kind}")
def export_csv(kind: str, template: bool = False, user=Depends(current_user), db=Depends(get_db)):
    if kind not in KINDS:
        raise HTTPException(404, "Unknown dataset. Use products, campaigns, daily or inventory.")
    table, cols, _, _ = KINDS[kind]
    out = io.StringIO()
    w = csv.writer(out)
    w.writerow(cols)
    if template:
        w.writerow(EXAMPLES[kind])
    else:
        for r in rows(db, f"SELECT {', '.join(cols)} FROM {table} WHERE org_id=? ORDER BY 1, 2", (user["org_id"],)):
            w.writerow([r[c] for c in cols])
    name = f"athena_{kind}{'_template' if template else ''}.csv"
    return Response(out.getvalue(), media_type="text/csv", headers={"Content-Disposition": f'attachment; filename="{name}"'})


@router.post("/api/import/{kind}")
def import_csv(kind: str, payload: CsvIn, request: Request, user=Depends(current_user), db=Depends(get_db)):
    if kind not in KINDS:
        raise HTTPException(404, "Unknown dataset. Use products, campaigns, daily or inventory.")
    table, cols, required, key = KINDS[kind]
    org = user["org_id"]
    reader = csv.DictReader(io.StringIO(payload.csv.lstrip("\ufeff")))
    reader.fieldnames = [(h or "").strip().lower() for h in (reader.fieldnames or [])]
    missing = [c for c in required if c not in reader.fieldnames]
    if missing:
        raise HTTPException(400, f"Missing column(s): {', '.join(missing)}")
    known = {"skus": {r["sku"] for r in rows(db, "SELECT sku FROM products WHERE org_id=?", (org,))},
             "campaigns": {r["campaign_id"] for r in rows(db, "SELECT campaign_id FROM campaigns WHERE org_id=?", (org,))}}
    data, errors = [], []
    for line, row in enumerate(reader, start=2):
        if len(data) + len(errors) > MAX_ROWS:
            raise HTTPException(413, f"At most {MAX_ROWS} rows per import")
        if not any(str(v or "").strip() for v in row.values()):
            continue
        try:
            data.append(_clean(kind, row, known))
        except ValueError as e:
            errors.append(f"Row {line}: {e}")
    if errors:
        raise HTTPException(400, "; ".join(errors[:5]) + (f" (and {len(errors) - 5} more)" if len(errors) > 5 else ""))
    if not data:
        raise HTTPException(400, "The file has no data rows")
    ts = now_iso()
    ins_cols = ["org_id", *cols, "source"] + (["updated_at"] if kind in ("products", "inventory") else [])
    extra = ["user_import"] + ([ts] if kind in ("products", "inventory") else [])
    upd = ", ".join(f"{c}=COALESCE(excluded.{c}, {table}.{c})" if c not in required else f"{c}=excluded.{c}" for c in cols if c not in key)
    upd += ", source=excluded.source" + (", updated_at=excluded.updated_at" if kind in ("products", "inventory") else "")
    sql = f"INSERT INTO {table} ({', '.join(ins_cols)}) VALUES ({', '.join('?' * len(ins_cols))}) ON CONFLICT({', '.join(key)}) DO UPDATE SET {upd}"
    with transaction(db):
        db.executemany(sql, [[org, *r, *extra] for r in data])
        audit(db, user, "data_import", f"{len(data)} rows into {kind}", request)
    return {"imported": len(data), "kind": kind}
