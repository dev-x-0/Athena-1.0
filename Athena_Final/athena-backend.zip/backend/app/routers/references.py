import json

from fastapi import APIRouter, Depends, HTTPException, Query

from ..db import get_db, one, rows
from ..deps import current_user
from ..engine.provenance import CATALOG, ORIGIN_LABELS, USER_FIELDS, build_references

router = APIRouter(tags=["references"])

_ORG_TABLES = {
    "products": "Product master: names, price, cost and margin", "campaigns": "Campaign definitions and the SKU each promotes",
    "campaign_daily": "Daily spend and attributed revenue per campaign", "inventory": "Units on hand per SKU",
}


@router.get("/api/references")
def references(analysis_id: str | None = Query(None, description="Limit to the references used by one analysis run"),
               user=Depends(current_user), db=Depends(get_db)):
    org = user["org_id"]
    if analysis_id:
        row = one(db, "SELECT result_json FROM analysis_runs WHERE id=? AND org_id=?", (analysis_id, org))
        if not row:
            raise HTTPException(404, "Analysis not found")
        res = json.loads(row["result_json"])
        return {"scope": "analysis", "analysis_id": analysis_id, "references": res["references"], "data_gaps": res.get("data_gaps", [])}
    datasets = []
    for t, desc in _ORG_TABLES.items():
        n = one(db, f"SELECT COUNT(*) AS n FROM {t} WHERE org_id=?", (org,))["n"]
        srcs = [r["source"] for r in rows(db, f"SELECT DISTINCT source FROM {t} WHERE org_id=?", (org,))]
        rng = one(db, "SELECT MIN(day) AS start, MAX(day) AS end FROM campaign_daily WHERE org_id=?", (org,)) if t == "campaign_daily" else None
        datasets.append({"name": t, "scope": "organization", "description": desc, "rows": n, "date_range": rng if rng and rng["start"] else None,
                         "origin": srcs, "origin_labels": [ORIGIN_LABELS.get(s, s) for s in srcs], "used_in_analysis": True,
                         "fields": [k.split(".", 1)[1] for k in CATALOG if k.startswith(t + ".")]})
    for d in rows(db, "SELECT * FROM legacy_datasets ORDER BY table_name"):
        extra = None
        note = "Preserved from the original MySQL dump. Its keys and scales do not link to your campaigns, so Athena does not blend it into calculations."
        if d["table_name"] == "revenu_prediction_for_30_days":
            st = one(db, 'SELECT MIN("Date") AS a, MAX("Date") AS b, COUNT(*) AS n, AVG(CAST("Predicted_Revenue" AS REAL)) AS avg FROM legacy_revenu_prediction_for_30_days')
            extra = {"start": st["a"], "end": st["b"]}
            note = (f"An existing 30-day revenue forecast ({st['a'][:10]} to {st['b'][:10]}, average {st['avg']:,.0f} per day). It is not linked to your SKUs and covers a different period "
                    "and scale, so it is shown for reference and not blended with your campaign forecasts.")
        datasets.append({"name": f"legacy_{d['table_name']}", "scope": "legacy", "description": "Legacy dataset", "rows": d["row_count"], "date_range": extra,
                         "origin": ["legacy_dump"], "origin_labels": [ORIGIN_LABELS["legacy_dump"]], "used_in_analysis": False, "usage_note": note,
                         "fields": json.loads(d["columns_json"])})
    catalog = build_references(db, org, list(CATALOG) + [f"user_input.{f}" for f in USER_FIELDS])
    return {"scope": "catalog", "datasets": datasets, "references": catalog,
            "legend": {"OBSERVED": "read directly from data", "DERIVED": "calculated", "FORECAST": "predicted by an Athena method", "ASSUMED": "typed in by the user"}}
