from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request, Response

from ..config import settings
from ..db import get_db, now_iso, one, transaction
from ..deps import audit, current_user
from ..schemas import LoginIn, SignupIn
from ..security import (DUMMY_HASH, hash_password, hash_token, new_token, throttle, validate_password,
                        validate_username, verify_password)
from ..seed import seed_org

router = APIRouter(prefix="/auth", tags=["auth"])


def _start_session(db, response: Response, user_id: int) -> dict:
    cfg, token = settings(), new_token()
    exp = datetime.now(timezone.utc) + timedelta(hours=cfg.session_ttl_hours)
    db.execute("INSERT INTO sessions VALUES (?,?,?,?)", (hash_token(token), user_id, now_iso(), exp.isoformat(timespec="seconds")))
    response.set_cookie(cfg.cookie_name, token, httponly=True, samesite="lax", secure=cfg.cookie_secure,
                        max_age=cfg.session_ttl_hours * 3600, path="/")
    return {"token": token, "expires_at": exp.isoformat(timespec="seconds"), "token_type": "bearer"}


def _user_payload(row: dict) -> dict:
    return {"id": row["id"], "username": row["username"], "org": {"id": row["org_id"], "name": row["org_name"]}}


@router.post("/signup", status_code=201)
def signup(body: SignupIn, request: Request, response: Response, db=Depends(get_db)):
    username = body.username.strip()
    err = validate_username(username) or validate_password(body.password, username)
    if err:
        raise HTTPException(422, err)
    if one(db, "SELECT 1 FROM users WHERE username_lower=?", (username.lower(),)):
        raise HTTPException(409, "That username is taken.")
    pw = hash_password(body.password)
    company = (body.company_name or "").strip() or f"{username}'s company"
    with transaction(db):
        org_id = db.execute("INSERT INTO organizations (name, created_at) VALUES (?,?)", (company, now_iso())).lastrowid
        uid = db.execute("INSERT INTO users (org_id, username, username_lower, password_hash, created_at, last_login_at) VALUES (?,?,?,?,?,?)",
                         (org_id, username, username.lower(), pw, now_iso(), now_iso())).lastrowid
        if body.load_sample_data:
            seed_org(db, org_id)
        sess = _start_session(db, response, uid)
        audit(db, {"id": uid, "org_id": org_id}, "signup", f"user {username} created; sample_data={body.load_sample_data}", request)
    return {"user": {"id": uid, "username": username, "org": {"id": org_id, "name": company}}, **sess}


@router.post("/login")
def login(body: LoginIn, request: Request, response: Response, db=Depends(get_db)):
    key = (body.username.strip().lower(), request.client.host if request.client else "?")
    if throttle.blocked(key):
        raise HTTPException(429, "Too many failed attempts. Try again in a few minutes.")
    row = one(db, "SELECT u.*, o.name AS org_name FROM users u JOIN organizations o ON o.id=u.org_id WHERE u.username_lower=?", (key[0],))
    ok = verify_password(body.password, row["password_hash"] if row else DUMMY_HASH)
    if not row or not ok:
        throttle.record_failure(key)
        audit(db, None, "login_failed", f"username={key[0][:40]}", request, org_id=row["org_id"] if row else None)
        raise HTTPException(401, "Invalid username or password.")
    throttle.clear(key)
    db.execute("UPDATE users SET last_login_at=? WHERE id=?", (now_iso(), row["id"]))
    sess = _start_session(db, response, row["id"])
    audit(db, row, "login", "login ok", request)
    return {"user": _user_payload(row), **sess}


@router.post("/logout")
def logout(request: Request, response: Response, user=Depends(current_user), db=Depends(get_db)):
    db.execute("DELETE FROM sessions WHERE token_hash=?", (user["token_hash"],))
    audit(db, user, "logout", "logout", request)
    response.delete_cookie(settings().cookie_name, path="/")
    return {"ok": True}


@router.get("/me")
def me(user=Depends(current_user)):
    return {"user": _user_payload(user), "session_expires_at": user["expires_at"]}
