"""Dashboard, campaigns, products, inventory, insights, alerts, audit, command centre."""
from fastapi import APIRouter, Depends, HTTPException, Query, Request

from ..config import settings
from ..db import get_db, now_iso, one, rows, transaction
from ..deps import audit, current_user
from ..engine import alerts as alerts_engine
from ..engine import insights as insights_engine
from ..engine.forecast import differs_from_trailing, linear_forecast
from ..engine.metrics import (DERIVED, FORECAST, OBSERVED, RANGES, campaign_stats, daily_series, latest_day, metric,
                              pct_change, safe_div, stock_map, totals, window)
from ..engine.portfolio import campaign_view
from ..schemas import InventoryIn
from ..seed import remove_sample

router = APIRouter(tags=["data"])


def _range(value: str) -> str:
    if value not in RANGES:
        raise HTTPException(400, "range must be one of: 7d, 30d, qtd")
    return value


def _kpi(key, label, cur, prev, unit, type_, formula, sources, tr, note=None):
    m = metric(key, label, cur, unit, type_, formula, sources, time_range=tr, note=note)
    m["previous"] = None if prev is None else round(prev, 2)
    m["delta_pct"] = pct_change(cur, prev)
    return m


@router.get("/api/dashboard")
def dashboard(period_q: str = Query("qtd", alias="range"), user=Depends(current_user), db=Depends(get_db)):
    period, org = _range(period_q), user["org_id"]
    latest = latest_day(db, org)
    cfg = settings()
    alerts = alerts_engine.generate(db, org)
    base = {"range": period, "roas_floor": cfg.roas_floor, "low_stock_threshold": cfg.low_stock,
            "alerts": {"total": len(alerts), "critical": sum(a["severity"] == "CRITICAL" for a in alerts),
                       "warning": sum(a["severity"] == "WARNING" for a in alerts), "items": alerts[:8]}}
    if not latest:
        return {**base, "data_status": {"has_data": False, "latest_day": None, "message": "No campaign performance data yet. Import data or load sample data."},
                "kpis": [], "trajectory": None, "channels": [], "campaigns": [], "inventory_summary": inventory_summary(db, org), "forecast": None, "insights": []}
    s, e, bucket = window(latest, period)
    ps, pe, _ = window(latest, period, 1)
    cur, prev = campaign_stats(db, org, s, e), campaign_stats(db, org, ps, pe)
    T, P = totals(cur), totals(prev)
    tr = f"{s} to {e} vs {ps} to {pe}"
    cov = T["contribution_revenue_coverage"]
    kpis = [
        _kpi("ad_spend", "Ad spend", T["spend"], P["spend"], "INR", OBSERVED, "SUM(spend)", ["campaign_daily.spend"], tr),
        _kpi("gross_revenue", "Gross revenue", T["revenue"], P["revenue"], "INR", OBSERVED, "SUM(revenue)", ["campaign_daily.revenue"], tr, "Direct-attribution revenue"),
        _kpi("blended_roas", "Blended ROAS", T["roas"], P["roas"], "x", DERIVED, "revenue / advertising_spend", ["campaign_daily.revenue", "campaign_daily.spend"], tr),
        _kpi("net_contribution", "Net contribution", T["contribution"], P["contribution"], "INR", DERIVED, "SUM(revenue x margin_pct/100 - spend)",
             ["campaign_daily.revenue", "campaign_daily.spend", "products.margin_pct"], tr,
             None if cov in (None, 1) else f"Covers {cov * 100:.0f}% of revenue; campaigns without a known margin are excluded"),
    ]
    daily = daily_series(db, org, s, e)
    labels, rev, sp = [], [], []
    for i in range(0, len(daily), bucket):
        ch = daily[i:i + bucket]
        labels.append(ch[0]["day"]); rev.append(round(sum(d["revenue"] for d in ch), 2)); sp.append(round(sum(d["spend"] for d in ch), 2))
    traj = {"id": "trajectory", "type": "area", "title": "Attributed revenue vs ad spend", "unit": "INR", "bucket_days": bucket, "x": labels,
            "series": [{"name": "Revenue", "kind": "observed", "values": rev}, {"name": "Ad spend", "kind": "observed", "values": sp}]}
    chans = {}
    for c in cur:
        a = chans.setdefault(c["channel"], {"channel": c["channel"], "spend": 0.0, "revenue": 0.0})
        a["spend"] += c["spend"]; a["revenue"] += c["revenue"]
    channels = sorted(({**a, "spend": round(a["spend"], 2), "revenue": round(a["revenue"], 2), "roas": None if not a["spend"] else round(a["revenue"] / a["spend"], 3)} for a in chans.values()), key=lambda a: -a["spend"])
    view = campaign_view(db, org, period)
    camps = [{k: c[k] for k in ("campaign_id", "name", "channel", "sku", "product_name", "spend", "revenue", "roas", "contribution", "margin_pct", "stock_units", "roas_trend_pct")} | {"action": c["decision"]["action"], "reason": (c["decision"]["rationale"] or [""])[0]} for c in view["campaigns"]]
    camps.sort(key=lambda c: (c["contribution"] is None, -(c["contribution"] or 0)))
    series = [{"day": d["day"], "value": d["revenue"]} for d in daily_series(db, org, window(latest, "30d")[0], latest)]
    fc = linear_forecast(series, 7)
    forecast = None
    if fc:
        last7 = sum(x["value"] for x in series[-7:])
        forecast = {"type": FORECAST, "horizon_days": 7, "revenue": fc["total"], "change_vs_last_7d_pct": pct_change(fc["total"]["base"], last7), "change_is_significant": differs_from_trailing(fc, last7),
                    "method": fc["method"], "r2": fc["r2"], "note": fc["interval_note"], "sources": ["campaign_daily.revenue", "method.linear_trend_forecast"]}
    return {**base, "data_status": {"has_data": True, "latest_day": latest, "window": {"start": s, "end": e, "prior_start": ps, "prior_end": pe}},
            "kpis": kpis, "trajectory": traj, "channels": channels, "campaigns": camps, "inventory_summary": inventory_summary(db, org),
            "forecast": forecast, "insights": insights_engine.build(db, org, period)["items"][:3]}


def inventory_summary(db, org):
    low = settings().low_stock
    st = stock_map(db, org)
    return {"total_skus": len(st), "out_of_stock": sum(v["stock_level"] <= 0 for v in st.values()),
            "low_stock": sum(0 < v["stock_level"] < low for v in st.values()), "threshold": low}


@router.get("/api/campaigns")
def campaigns(period_q: str = Query("qtd", alias="range"), user=Depends(current_user), db=Depends(get_db)):
    period = _range(period_q)
    view = campaign_view(db, user["org_id"], period)
    out = []
    for c in view["campaigns"]:
        d = c["decision"]
        out.append({"campaign_id": c["campaign_id"], "name": c["name"], "channel": c["channel"], "sku": c["sku"], "product_name": c["product_name"],
                    "spend": c["spend"], "revenue": c["revenue"], "roas": None if c["roas"] is None else round(c["roas"], 3), "prior_roas": None if c["prior_roas"] is None else round(c["prior_roas"], 3),
                    "roas_trend_pct": c["roas_trend_pct"], "break_even_roas": None if c["break_even_roas"] is None else round(c["break_even_roas"], 3),
                    "contribution": c["contribution"], "margin_pct": c["margin_pct"], "conversions": c["conversions"], "cpa": c["cpa"], "stock_units": c["stock_units"],
                    "days_with_data": c["days"], "decision": {"action": d["action"], "label": d["label"], "spend_change_pct": d["spend_change_pct"], "rationale": d["rationale"],
                                                              "conflicts": d["conflicts"], "evidence": d["evidence"], "reason_codes": d["reason_codes"]}})
    return {"range": period, "window": view.get("window"), "has_data": view["has_data"], "items": out,
            "sources": ["campaign_daily.spend", "campaign_daily.revenue", "products.margin_pct", "inventory.stock_level", "method.decision_rules"]}


@router.get("/api/products")
def products(user=Depends(current_user), db=Depends(get_db)):
    org, latest = user["org_id"], None
    latest = latest_day(db, org)
    stats = {}
    if latest:
        s, e, _ = window(latest, "30d")
        for c in campaign_stats(db, org, s, e):
            if c["sku"]:
                a = stats.setdefault(c["sku"], {"spend": 0.0, "revenue": 0.0, "campaigns": []})
                a["spend"] += c["spend"]; a["revenue"] += c["revenue"]; a["campaigns"].append(c["campaign_id"])
    stock = stock_map(db, org)
    out = []
    for p in rows(db, "SELECT sku, name, category, selling_price, unit_cost, margin_pct, source, updated_at FROM products WHERE org_id=? ORDER BY sku", (org,)):
        a = stats.get(p["sku"], {"spend": 0.0, "revenue": 0.0, "campaigns": []})
        out.append({**p, "stock_level": (stock.get(p["sku"]) or {}).get("stock_level"), "campaign_ids": a["campaigns"],
                    "ad_spend_30d": round(a["spend"], 2), "ad_revenue_30d": round(a["revenue"], 2), "roas_30d": safe_div(a["revenue"], a["spend"]) and round(a["revenue"] / a["spend"], 3)})
    return {"items": out, "sources": ["products.*", "inventory.stock_level", "campaign_daily.*"]}


def _inv_rows(db, org):
    cfg, view = settings(), {c["sku"]: c for c in campaign_view(db, org, "30d")["campaigns"] if c["sku"]}
    out = []
    for r in rows(db, """SELECT i.sku, p.name AS product_name, i.stock_level, i.reserved, p.margin_pct, p.selling_price, p.unit_cost, i.source, i.updated_at
                         FROM inventory i JOIN products p ON p.org_id=i.org_id AND p.sku=i.sku WHERE i.org_id=? ORDER BY i.sku""", (org,)):
        c = view.get(r["sku"])
        r["available"] = None if r["reserved"] is None else max(0, r["stock_level"] - r["reserved"])
        r["stock_status"] = "OUT" if r["stock_level"] <= 0 else "LOW" if r["stock_level"] < cfg.low_stock else "OK"
        r["campaign_id"] = c["campaign_id"] if c else None
        r["campaign_action"] = c["decision"]["action"] if c else None
        out.append(r)
    return out


@router.get("/api/inventory")
def inventory(user=Depends(current_user), db=Depends(get_db)):
    return {"low_stock_threshold": settings().low_stock, "items": _inv_rows(db, user["org_id"]), "sources": ["inventory.stock_level", "products.*", "method.decision_rules"]}


@router.post("/api/inventory", status_code=201)
def upsert_inventory(body: InventoryIn, request: Request, user=Depends(current_user), db=Depends(get_db)):
    org, ts, sku = user["org_id"], now_iso(), body.sku.strip()
    prod = one(db, "SELECT * FROM products WHERE org_id=? AND sku=?", (org, sku))
    if not prod and not body.product_name:
        raise HTTPException(422, "product_name is required for a new SKU")
    with transaction(db):
        if not prod:
            db.execute("INSERT INTO products (org_id, sku, name, category, selling_price, unit_cost, margin_pct, source, updated_at) VALUES (?,?,?,?,?,?,?,?,?)",
                       (org, sku, body.product_name, body.category, body.selling_price, body.unit_cost, body.margin_pct, "user_entry", ts))
        else:
            upd = {k: v for k, v in {"name": body.product_name, "category": body.category, "selling_price": body.selling_price, "unit_cost": body.unit_cost, "margin_pct": body.margin_pct}.items() if v is not None}
            if upd:
                db.execute(f"UPDATE products SET {', '.join(f'{k}=?' for k in upd)}, source='user_entry', updated_at=? WHERE org_id=? AND sku=?", (*upd.values(), ts, org, sku))
        db.execute("""INSERT INTO inventory (org_id, sku, stock_level, reserved, source, updated_at) VALUES (?,?,?,?,?,?)
                      ON CONFLICT(org_id, sku) DO UPDATE SET stock_level=excluded.stock_level, reserved=COALESCE(excluded.reserved, reserved), source='user_entry', updated_at=excluded.updated_at""",
                   (org, sku, body.stock_level, body.reserved, "user_entry", ts))
        audit(db, user, "inventory_update", f"{sku}: stock_level={body.stock_level}", request)
    return next(r for r in _inv_rows(db, org) if r["sku"] == sku)


@router.get("/api/insights")
def insights(period_q: str = Query("qtd", alias="range"), user=Depends(current_user), db=Depends(get_db)):
    return insights_engine.build(db, user["org_id"], _range(period_q))


@router.get("/api/alerts")
def alerts(include_acknowledged: bool = True, user=Depends(current_user), db=Depends(get_db)):
    items = alerts_engine.generate(db, user["org_id"])
    if not include_acknowledged:
        items = [a for a in items if not a["acknowledged"]]
    return {"total": len(items), "items": items}


@router.post("/api/alerts/{code:path}/acknowledge")
def acknowledge(code: str, request: Request, user=Depends(current_user), db=Depends(get_db)):
    alert = next((a for a in alerts_engine.generate(db, user["org_id"]) if a["code"] == code), None)
    if not alert:
        raise HTTPException(404, "Alert not found (it may no longer apply)")
    with transaction(db):
        if alert["acknowledged"]:
            db.execute("DELETE FROM alert_ack WHERE org_id=? AND code=?", (user["org_id"], code))
        else:
            db.execute("INSERT INTO alert_ack VALUES (?,?,?,?)", (user["org_id"], code, user["id"], now_iso()))
        audit(db, user, "alert_restore" if alert["acknowledged"] else "alert_acknowledge", code, request)
    return {**alert, "acknowledged": not alert["acknowledged"]}


@router.get("/api/audit")
def audit_trail(limit: int = Query(50, ge=1, le=200), user=Depends(current_user), db=Depends(get_db)):
    return {"items": rows(db, """SELECT a.id, a.ts, a.action, a.detail, u.username AS user FROM audit_log a LEFT JOIN users u ON u.id=a.user_id
                                  WHERE a.org_id=? ORDER BY a.id DESC LIMIT ?""", (user["org_id"], limit))}


@router.delete("/api/data/sample")
def delete_sample(request: Request, user=Depends(current_user), db=Depends(get_db)):
    with transaction(db):
        removed = remove_sample(db, user["org_id"])
        audit(db, user, "sample_data_removed", str(removed), request)
    return {"removed": removed}


@router.get("/api/command-center")
def command_center(user=Depends(current_user), db=Depends(get_db)):
    org = user["org_id"]
    last = one(db, "SELECT id, title, created_at, headline, top_action FROM analysis_runs WHERE org_id=? ORDER BY created_at DESC, rowid DESC LIMIT 1", (org,))
    n = one(db, "SELECT COUNT(*) AS n FROM analysis_runs WHERE org_id=?", (org,))["n"]
    al = alerts_engine.generate(db, org)
    org_ds = sum(1 for t in ("products", "campaigns", "campaign_daily", "inventory") if one(db, f"SELECT 1 FROM {t} WHERE org_id=? LIMIT 1", (org,)))
    legacy = one(db, "SELECT COUNT(*) AS n FROM legacy_datasets")["n"]
    return {"user": {"id": user["id"], "username": user["username"], "org": {"id": org, "name": user["org_name"]}}, "modes": [
        {"key": "history", "title": "Analysis History", "route": "/history", "count": n, "latest": last, "subtitle": "What Athena told you, and the data behind it"},
        {"key": "run_analysis", "title": "Run Analysis", "route": "/analysis/new", "count": None, "inventory_skus": inventory_summary(db, org)["total_skus"],
         "subtitle": "Test inventory and advertising scenarios against your data"},
        {"key": "references", "title": "Data References", "route": "/references", "count": org_ds + legacy, "subtitle": "Where every number comes from"}],
        "alerts": {"total": len(al), "critical": sum(a["severity"] == "CRITICAL" for a in al)}, "data_status": {"has_data": latest_day(db, org) is not None, "latest_day": latest_day(db, org)}}
