"""Auth dependency (cookie or Bearer token) and audit helper."""
from datetime import datetime, timezone

from fastapi import Depends, HTTPException, Request

from .config import settings
from .db import get_db, now_iso, one
from .security import hash_token


def _token(request: Request) -> str | None:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return request.cookies.get(settings().cookie_name)


def current_user(request: Request, db=Depends(get_db)) -> dict:
    token = _token(request)
    if not token:
        raise HTTPException(401, "Not authenticated")
    row = one(
        db,
        """SELECT u.id, u.username, u.org_id, o.name AS org_name, s.expires_at
           FROM sessions s JOIN users u ON u.id = s.user_id JOIN organizations o ON o.id = u.org_id
           WHERE s.token_hash = ?""",
        (hash_token(token),),
    )
    if not row:
        raise HTTPException(401, "Invalid session")
    if datetime.fromisoformat(row["expires_at"]) < datetime.now(timezone.utc):
        db.execute("DELETE FROM sessions WHERE token_hash = ?", (hash_token(token),))
        raise HTTPException(401, "Session expired")
    row["token_hash"] = hash_token(token)
    return row


def audit(db, user: dict | None, action: str, detail: str, request: Request | None = None, org_id=None):
    ip = request.client.host if request and request.client else None
    db.execute(
        "INSERT INTO audit_log (org_id, user_id, ts, action, detail, ip) VALUES (?,?,?,?,?,?)",
        ((user or {}).get("org_id", org_id), (user or {}).get("id"), now_iso(), action, detail[:500], ip),
    )
