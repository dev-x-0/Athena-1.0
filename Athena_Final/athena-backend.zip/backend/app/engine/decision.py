"""Decision engine: SCALE / HOLD / REDUCE / PAUSE / REVIEW from multiple pieces of evidence.

Never decides from one metric. When signals disagree it says so (conflicts) instead of picking silently.
Thresholds below are POLICY constants (documented in provenance 'method.decision_rules'), not learned values.
"""
SCALE_HEADROOM = 1.15      # ROAS must exceed break-even by 15% (and the floor) to scale
WEAK_MARGIN_PCT = 15.0     # below this, revenue growth alone never triggers SCALE
DETERIORATION_PCT = -20.0  # ROAS trend (30d vs prior 30d) at/below this = deteriorating
CRITICAL_COVER_DAYS = 7
NEAR_BREAK_EVEN = 0.90     # within 10% below break-even is "marginal", not "losing": hold, do not whipsaw
ABOVE_RUN_RATE = 1.5       # planned spend already >50% above trailing run-rate: no further scale step
MIN_DATA_DAYS = 7
STEP_SCALE_PCT = 20        # policy step sizes, not predictions
STEP_REDUCE_PCT = -30
SEVERITY = {"PAUSE": 5, "REDUCE": 4, "REVIEW": 3, "HOLD": 2, "SCALE": 1}
LABELS = {"SCALE": "Scale spend", "HOLD": "Hold spend", "REDUCE": "Reduce spend", "PAUSE": "Pause spend",
          "REVIEW": "Needs human review"}


def _x(v):
    return "n/a" if v is None else f"{v:.2f}x"


def decide(ev: dict) -> dict:
    """ev keys: has_campaign, data_days, roas, roas_floor, break_even_roas, roas_trend_pct, margin_pct,
    stock_units, days_of_cover, low_stock, planned_spend, baseline_spend, max_useful_spend, forecast_change_pct."""
    roas, floor, be = ev.get("roas"), ev["roas_floor"], ev.get("break_even_roas")
    trend, margin, stock = ev.get("roas_trend_pct"), ev.get("margin_pct"), ev.get("stock_units")
    cover, low, fc = ev.get("days_of_cover"), ev["low_stock"], ev.get("forecast_change_pct")
    planned, base_sp, max_useful = ev.get("planned_spend"), ev.get("baseline_spend"), ev.get("max_useful_spend")
    evidence, conflicts, why, codes = [], [], [], []

    def sig(name, value, reading):
        evidence.append({"signal": name, "value": value, "reading": reading})

    # ---- evidence table (always shown) ----
    if roas is not None:
        sig("ROAS", round(roas, 3), "below floor" if roas < floor else "at/above floor")
        sig("ROAS floor", floor, "policy threshold")
    if be is not None and roas is not None:
        sig("Break-even ROAS", round(be, 3), "ROAS is below break-even (losing money)" if roas < be else "ROAS clears break-even")
    if margin is not None:
        sig("Net margin %", margin, "weak" if margin < WEAK_MARGIN_PCT else "healthy")
    if trend is not None:
        sig("ROAS trend vs prior period %", trend, "deteriorating" if trend <= DETERIORATION_PCT else "stable/improving")
    if stock is not None:
        sig("Stock units", stock, "out of stock" if stock <= 0 else ("low" if stock < low else "adequate"))
    if cover is not None:
        sig("Days of stock cover", round(cover, 1), "critical" if cover < CRITICAL_COVER_DAYS else "ok")
    if fc is not None:
        sig("Forecast revenue change % (statistically distinguishable)", fc, "falling" if fc < -10 else ("rising" if fc > 10 else "flat"))
    if planned is not None and max_useful is not None:
        sig("Planned spend vs stock-supported spend", round(planned - max_useful, 2),
            "exceeds what the stock can convert" if planned > max_useful else "within stock-supported spend")

    # ---- insufficient evidence ----
    if not ev.get("has_campaign") or roas is None or ev.get("data_days", 0) < MIN_DATA_DAYS:
        why.append("Not enough advertising history linked to this item to judge efficiency "
                   f"(need a campaign with >= {MIN_DATA_DAYS} days of spend and revenue).")
        if stock is not None and stock <= 0:
            why.append("Stock is zero - do not start advertising until it is replenished.")
        return _out("REVIEW", 0, why, evidence, conflicts, ["INSUFFICIENT_EVIDENCE"])

    stock_out = stock is not None and stock <= 0
    crit_cover = cover is not None and cover < CRITICAL_COVER_DAYS
    crit_stock = crit_cover or (cover is None and stock is not None and stock < low)
    below_floor = roas < floor
    losing = be is not None and roas < be
    weak_margin = margin is not None and margin < WEAK_MARGIN_PCT
    deteriorating = trend is not None and trend <= DETERIORATION_PCT
    over_supply = planned is not None and max_useful is not None and planned > max_useful
    near_be = losing and roas >= NEAR_BREAK_EVEN * be
    horizon = ev.get("horizon_days")
    runs_out = cover is not None and horizon is not None and cover < horizon
    above_run = planned is not None and base_sp and planned > ABOVE_RUN_RATE * base_sp
    passes_scale = be is not None and roas >= max(floor, be * SCALE_HEADROOM)

    # ---- conflicts: stated whenever signals disagree ----
    if not below_floor and losing:
        conflicts.append(f"ROAS {_x(roas)} clears the {_x(floor)} floor but is below the {_x(be)} needed to break even at a "
                         f"{margin:.1f}% margin - revenue is growing while profit is not.")
    if not below_floor and weak_margin:
        conflicts.append(f"ROAS {_x(roas)} looks healthy but margin is only {margin:.1f}%, so revenue growth is not profit growth.")
    if not below_floor and deteriorating:
        conflicts.append(f"ROAS {_x(roas)} is above floor but has fallen {abs(trend):.0f}% versus the prior period.")
    if runs_out and not crit_stock and not below_floor:
        conflicts.append(f"At the expected demand the planned stock lasts {cover:.1f} days, shorter than the {horizon}-day horizon - spend would outrun stock.")
    if (passes_scale or not below_floor) and crit_stock:
        conflicts.append("Advertising efficiency is acceptable but stock is critically low - extra spend would drive demand Athena cannot fulfil.")
    if fc is not None and fc > 10 and (crit_stock or stock_out):
        conflicts.append(f"Revenue is forecast to rise {fc:.0f}% but stock cannot support it.")
    if fc is not None and fc < -10 and passes_scale:
        conflicts.append(f"Current ROAS supports scaling but the revenue trend forecast is {fc:.0f}%.")
    if margin is None and not below_floor:
        conflicts.append("ROAS is acceptable but margin is unknown, so profitability cannot be confirmed.")

    # ---- ordered rules ----
    if stock_out:
        action, codes = "PAUSE", ["STOCK_OUT"]
        why.append("Stock is zero: ad spend cannot convert into sales.")
    elif margin is not None and margin <= 0:
        action, codes = "PAUSE", ["NON_POSITIVE_MARGIN"]
        why.append(f"Margin is {margin:.1f}%: no ROAS can make this product profitable at current economics.")
    elif losing:
        if roas < 0.5 * be:
            action, codes = "PAUSE", ["FAR_BELOW_BREAK_EVEN"]
            why.append(f"ROAS {_x(roas)} is under half of the {_x(be)} break-even for a {margin:.1f}% margin; every rupee spent loses money.")
        elif near_be:
            action, codes = "HOLD", ["NEAR_BREAK_EVEN"]
            why.append(f"ROAS {_x(roas)} is marginally below the {_x(be)} break-even ({(1 - roas / be) * 100:.0f}% short) - close enough to normal variation that cutting spend would be premature; hold and monitor.")
        else:
            action, codes = "REDUCE", ["BELOW_BREAK_EVEN"]
            why.append(f"ROAS {_x(roas)} is below the {_x(be)} break-even for a {margin:.1f}% margin.")
    elif below_floor:
        action, codes = "REDUCE", ["BELOW_ROAS_FLOOR"]
        why.append(f"ROAS {_x(roas)} is below the {_x(floor)} efficiency floor" + (" and margin is unknown." if margin is None else "."))
    elif over_supply:
        action, codes = "REDUCE", ["SPEND_EXCEEDS_STOCK"]
        why.append("Planned spend exceeds what the available stock can convert at the observed ROAS.")
    elif crit_stock:
        action, codes = "HOLD", ["STOCK_CRITICAL"]
        why.append("ROAS is acceptable but stock cover is critical: hold spend and replenish before scaling.")
    elif runs_out:
        action, codes = "HOLD", ["STOCK_RUNS_OUT_IN_HORIZON"]
        why.append(f"Planned stock covers {cover:.1f} days of expected demand, less than the {horizon}-day horizon: replenish before adding spend.")
    elif weak_margin:
        action, codes = "HOLD", ["WEAK_MARGIN"]
        why.append(f"Margin {margin:.1f}% is weak, so higher revenue does not justify scaling.")
    elif margin is None:
        action, codes = "HOLD", ["MARGIN_UNKNOWN"]
        why.append("Scaling needs a known margin; hold until product economics are supplied.")
    elif deteriorating and passes_scale:
        action, codes = "REVIEW", ["CONFLICTING_EVIDENCE"]
        why.append("Level of ROAS supports scaling, but the sharp deterioration contradicts it - a person should look before spend moves.")
    elif deteriorating:
        action, codes = "HOLD", ["ROAS_DETERIORATING"]
        why.append("ROAS is above the thresholds but deteriorating; hold and watch.")
    elif passes_scale and fc is not None and fc < -10:
        action, codes = "HOLD", ["FORECAST_FALLING"]
        why.append("ROAS supports scaling but the revenue forecast is falling; hold until the trend is understood.")
    elif passes_scale and above_run:
        action, codes = "HOLD", ["ALREADY_ABOVE_RUN_RATE"]
        why.append(f"Planned spend is already {(planned / base_sp - 1) * 100:.0f}% above the trailing run-rate; validate returns at that level before going further.")
    elif passes_scale:
        action, codes = "SCALE", ["EFFICIENT_AND_PROFITABLE"]
        why.append(f"ROAS {_x(roas)} exceeds both the floor and break-even by the required headroom ({SCALE_HEADROOM:.2f}x), with healthy margin and stock.")
    else:
        action, codes = "HOLD", ["WITHIN_OPERATING_RANGE"]
        why.append(f"ROAS {_x(roas)} is profitable but without enough headroom over break-even ({_x(be)}) to scale.")

    # ---- spend step (policy) ----
    ref = planned if planned is not None else base_sp
    change = 0
    if action == "SCALE":
        change = STEP_SCALE_PCT
        if max_useful is not None and ref:
            change = int(min(STEP_SCALE_PCT, max(0, (max_useful / ref - 1) * 100)))
            if change < STEP_SCALE_PCT:
                why.append(f"Scale step capped at +{change}% because stock supports no more spend than that.")
    elif action == "REDUCE":
        change = STEP_REDUCE_PCT
        if over_supply and planned:
            change = max(-100, int(round((max_useful / planned - 1) * 100)))
    elif action == "PAUSE":
        change = -100
    return _out(action, change, why, evidence, conflicts, codes)


def _out(action, change, why, evidence, conflicts, codes):
    return {"action": action, "label": LABELS[action], "spend_change_pct": change, "rationale": why,
            "evidence": evidence, "conflicts": conflicts, "reason_codes": codes}


def confidence(*, data_days, margin_known, weekly_cv, demand_known, price_known, has_campaign) -> dict:
    """Heuristic data-sufficiency score (NOT a statistical probability). Weighted share of evidence present."""
    if not has_campaign:
        days_f = 0.0
    else:
        days_f = 1.0 if data_days >= 28 else 0.6 if data_days >= 14 else 0.3 if data_days >= 7 else 0.0
    stab = 0.5 if weekly_cv is None else (1.0 if weekly_cv < 0.15 else 0.6 if weekly_cv < 0.35 else 0.3)
    factors = [
        {"factor": "Advertising history length", "weight": 0.35, "score": days_f, "detail": f"{data_days} days of campaign data"},
        {"factor": "Product margin known", "weight": 0.25, "score": 1.0 if margin_known else 0.0, "detail": "margin supplied" if margin_known else "margin missing"},
        {"factor": "ROAS stability", "weight": 0.15, "score": stab, "detail": "weekly ROAS variation" if weekly_cv is not None else "too little data to judge"},
        {"factor": "Demand provided or inferable", "weight": 0.15, "score": 1.0 if demand_known else 0.4, "detail": "demand available" if demand_known else "demand unknown"},
        {"factor": "Selling price known", "weight": 0.10, "score": 1.0 if price_known else 0.5, "detail": "price available" if price_known else "price missing"},
    ]
    score = round(sum(f["weight"] * f["score"] for f in factors), 2)
    return {"level": "HIGH" if score >= 0.75 else "MEDIUM" if score >= 0.5 else "LOW", "score": score,
            "basis": "Heuristic share of required evidence present (weights shown); not a statistical probability.",
            "factors": factors}
