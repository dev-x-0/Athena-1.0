"""Ingestion/normalisation layer: org-scoped aggregation queries plus the provenance-carrying Metric object."""
from datetime import date, timedelta
from statistics import mean, pstdev

from ..db import one, rows

OBSERVED, DERIVED, FORECAST, ASSUMED = "OBSERVED", "DERIVED", "FORECAST", "ASSUMED"
RANGES = {"7d": (7, 1), "30d": (30, 1), "qtd": (90, 7)}  # days in window, days per chart point
_DECIMALS = {"INR": 2, "x": 3, "%": 2, "units": 2, "days": 1, "score": 2}


def metric(key, label, value, unit, type_, formula=None, sources=None, inputs=None, note=None, time_range=None, **extra):
    """Every number Athena emits to the UI is one of these: value + type + formula + sources."""
    if isinstance(value, float):
        value = round(value, _DECIMALS.get(unit, 2))
    m = {"metric": key, "label": label, "value": value, "unit": unit, "type": type_, "formula": formula,
         "sources": list(sources or []), "inputs": inputs or {}, "time_range": time_range, "note": note}
    m.update(extra)
    return m


def safe_div(a, b):
    return None if b in (0, None) or a is None else a / b


def pct_change(cur, prev):
    return None if not prev or cur is None else round((cur - prev) / abs(prev) * 100, 1)


def latest_day(db, org_id) -> str | None:
    return (one(db, "SELECT MAX(day) AS d FROM campaign_daily WHERE org_id=?", (org_id,)) or {}).get("d")


def window(latest: str, period: str, offset: int = 0):
    days, bucket = RANGES[period]
    end = date.fromisoformat(latest) - timedelta(days=days * offset)
    start = end - timedelta(days=days - 1)
    return start.isoformat(), end.isoformat(), bucket


def campaign_stats(db, org_id, start, end) -> list[dict]:
    """Per-campaign totals for [start, end] with product economics joined in. Missing data stays None."""
    out = rows(
        db,
        """SELECT c.campaign_id, c.name, c.channel, c.sku, p.name AS product_name, p.margin_pct,
                  p.selling_price, p.unit_cost,
                  COALESCE(SUM(d.spend),0) AS spend, COALESCE(SUM(d.revenue),0) AS revenue,
                  COUNT(d.day) AS days, COUNT(d.conversions) AS conv_rows, SUM(d.conversions) AS conversions
           FROM campaigns c
           LEFT JOIN products p ON p.org_id=c.org_id AND p.sku=c.sku
           LEFT JOIN campaign_daily d ON d.org_id=c.org_id AND d.campaign_id=c.campaign_id AND d.day BETWEEN ? AND ?
           WHERE c.org_id=? GROUP BY c.campaign_id ORDER BY c.campaign_id""",
        (start, end, org_id),
    )
    for r in out:
        r["roas"] = safe_div(r["revenue"], r["spend"])
        r["cpa"] = safe_div(r["spend"], r["conversions"]) if r["conv_rows"] else None
        r["conversions"] = r["conversions"] if r["conv_rows"] else None
        m = r["margin_pct"]
        r["contribution"] = r["revenue"] * m / 100 - r["spend"] if m is not None else None
        r["break_even_roas"] = 100 / m if m and m > 0 else None
        for k in ("spend", "revenue"):
            r[k] = round(r[k], 2)
        if r["contribution"] is not None:
            r["contribution"] = round(r["contribution"], 2)
    return out


def totals(stats: list[dict]) -> dict:
    spend = sum(c["spend"] for c in stats)
    revenue = sum(c["revenue"] for c in stats)
    known = [c for c in stats if c["contribution"] is not None]
    cov = safe_div(sum(c["revenue"] for c in known), revenue)
    return {"spend": spend, "revenue": revenue, "roas": safe_div(revenue, spend),
            "contribution": sum(c["contribution"] for c in known) if known else None,
            "contribution_revenue_coverage": cov}


def daily_series(db, org_id, start, end, campaign_id=None) -> list[dict]:
    q = "SELECT day, SUM(spend) AS spend, SUM(revenue) AS revenue FROM campaign_daily WHERE org_id=? AND day BETWEEN ? AND ?"
    p = [org_id, start, end]
    if campaign_id:
        q += " AND campaign_id=?"
        p.append(campaign_id)
    return rows(db, q + " GROUP BY day ORDER BY day", p)


def weekly_roas(series: list[dict], weeks: int = 4) -> list[float | None]:
    """ROAS for each of the last `weeks` 7-day blocks (oldest first); None when a block lacks data."""
    if not series:
        return []
    end = date.fromisoformat(series[-1]["day"])
    out = []
    for w in range(weeks - 1, -1, -1):
        hi, lo = end - timedelta(days=7 * w), end - timedelta(days=7 * w + 6)
        block = [s for s in series if lo <= date.fromisoformat(s["day"]) <= hi]
        sp = sum(s["spend"] for s in block)
        out.append(round(sum(s["revenue"] for s in block) / sp, 3) if len(block) >= 4 and sp > 0 else None)
    return out


def roas_cv(weekly: list) -> float | None:
    vals = [v for v in weekly if v is not None]
    if len(vals) < 3 or mean(vals) == 0:
        return None
    return pstdev(vals) / mean(vals)


def stock_map(db, org_id) -> dict:
    return {r["sku"]: r for r in rows(db, "SELECT sku, stock_level, reserved, source, updated_at FROM inventory WHERE org_id=?", (org_id,))}
