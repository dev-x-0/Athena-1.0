"""Evidence-backed insights and the budget reallocation plan (ported from the prototype, now stock- and margin-aware)."""
from ..config import settings
from .forecast import differs_from_trailing, linear_forecast
from .metrics import daily_series, pct_change, window
from .portfolio import campaign_view


def money(n):
    s, a = ("-" if n < 0 else ""), abs(n)
    return f"{s}₹{a / 1e6:.2f}M" if a >= 1e6 else f"{s}₹{a / 1e3:.1f}K" if a >= 1e3 else f"{s}₹{a:.0f}"


def build(db, org_id, period="qtd") -> dict:
    view = campaign_view(db, org_id, period)
    if not view["has_data"]:
        return {"range": period, "items": [], "reallocation": {"items": [], "projected_gain": None, "note": "No performance data yet."}}
    camps = [c for c in view["campaigns"] if c["spend"]]
    items = []

    def add(tone, title, detail, evidence):
        items.append({"id": f"ins-{len(items) + 1}", "tone": tone, "title": title, "detail": detail, "evidence": evidence})

    known = sorted([c for c in camps if c["contribution"] is not None], key=lambda c: -c["contribution"])
    if known:
        b, w = known[0], known[-1]
        add("good" if b["contribution"] > 0 else "warn", f"Top contributor: {b['name']}",
            f"{b['campaign_id']} on {b['channel']} contributed {money(b['contribution'])} at {b['roas']:.2f}x ROAS.",
            ["campaign_daily.revenue", "campaign_daily.spend", "products.margin_pct"])
        if w["contribution"] < 0:
            add("warn", f"Biggest drag: {w['name']}", f"{w['campaign_id']} lost {money(abs(w['contribution']))} on {money(w['spend'])} of spend "
                f"(ROAS {w['roas']:.2f}x vs {w['break_even_roas']:.2f}x needed to break even). Action: {w['decision']['action']}.",
                ["campaign_daily.revenue", "campaign_daily.spend", "products.margin_pct", "method.break_even_roas"])
    chans = {}
    for c in camps:
        a = chans.setdefault(c["channel"], [0.0, 0.0])
        a[0] += c["spend"]; a[1] += c["revenue"]
    ch = {k: v[1] / v[0] for k, v in chans.items() if v[0]}
    if len(ch) > 1:
        top, low = max(ch, key=ch.get), min(ch, key=ch.get)
        add("info", f"{top} returns the most per rupee", f"{ch[top]:.2f}x ROAS against {ch[low]:.2f}x on {low}.", ["campaign_daily.revenue", "campaign_daily.spend", "campaigns.channel"])
    latest = view["latest"]
    series = [{"day": d["day"], "value": d["revenue"]} for d in daily_series(db, org_id, window(latest, "30d")[0], latest)]
    fc = linear_forecast(series, 7)
    if fc and len(series) >= 7:
        last7 = sum(s["value"] for s in series[-7:])
        ch7 = pct_change(fc["total"]["base"], last7) or 0
        sig = differs_from_trailing(fc, last7)
        add(("good" if ch7 >= 0 else "warn") if sig else "info", f"Next 7 days: about {money(fc['total']['base'])} revenue (FORECAST)",
            f"{abs(ch7):.1f}% {'above' if ch7 >= 0 else 'below'} the last 7 days" + ("" if sig else " - within normal day-to-day variation, so no real change is signalled") + f"; range {money(fc['total']['low'])} to {money(fc['total']['high'])}. {fc['interval_note']}",
            ["campaign_daily.revenue", "method.linear_trend_forecast"])
    low = settings().low_stock
    crit = sorted([c for c in camps if c["stock_units"] is not None and c["stock_units"] < low], key=lambda c: c["stock_units"])
    if crit:
        add("warn", f"{len(crit)} advertised SKU{'s' if len(crit) > 1 else ''} running low",
            ", ".join(f"{c['product_name']} ({c['stock_units']})" for c in crit[:3]) + ". Reorder before scaling spend.", ["inventory.stock_level", "campaigns.sku"])
    thin = [c for c in camps if c["margin_pct"] is not None and c["margin_pct"] < 15 and c["decision"]["action"] in ("SCALE",)]
    for c in camps:
        if c["margin_pct"] is not None and c["margin_pct"] < 15:
            add("warn", f"Thin margin on {c['product_name']}", f"{c['margin_pct']:.1f}% margin needs {c['break_even_roas']:.1f}x ROAS to break even; current is {c['roas']:.2f}x.",
                ["products.margin_pct", "method.break_even_roas"])
            break
    return {"range": period, "items": items, "reallocation": reallocate(camps)}


def reallocate(camps, cut_share=0.30, cap=0.50) -> dict:
    """Move budget from loss-making campaigns to profitable, in-stock, non-review campaigns. Assumes constant returns."""
    low = settings().low_stock
    rows = [c for c in camps if c["spend"] and c["contribution"] is not None]
    rate = lambda c: c["contribution"] / c["spend"]  # noqa: E731
    losers = [c for c in rows if c["contribution"] < 0]
    winners = [c for c in rows if c["contribution"] > 0 and c["decision"]["action"] != "REVIEW" and (c["stock_units"] is None or c["stock_units"] >= low)]
    pool = sum(c["spend"] * cut_share for c in losers)
    weight = sum(rate(c) for c in winners)
    adds = {c["campaign_id"]: min(pool * rate(c) / weight, c["spend"] * cap) for c in winners} if pool and weight else {}
    scale = sum(adds.values()) / pool if pool else 0
    out, gain = [], 0.0
    for c in rows:
        new = c["spend"] * (1 - cut_share * scale) if c in losers else c["spend"] + adds.get(c["campaign_id"], 0)
        gain += (new - c["spend"]) * rate(c)
        out.append({"campaign_id": c["campaign_id"], "name": c["name"], "current": round(c["spend"], 2), "recommended": round(new, 2),
                    "change": round(new - c["spend"], 2), "roas": None if c["roas"] is None else round(c["roas"], 3), "action": c["decision"]["action"]})
    out.sort(key=lambda i: i["change"])
    note = ("Moves up to 30% of budget from campaigns with negative contribution to profitable, adequately stocked ones (growth capped at +50% each). "
            "Assumes returns stay constant as spend changes - apply gradually.") if scale else \
           "No reallocation suggested: there are no loss-making campaigns, or no profitable in-stock campaigns to receive budget."
    return {"items": out, "projected_gain": round(gain, 2) if scale else None, "projected_gain_type": "FORECAST", "note": note,
            "campaigns_excluded_for_missing_margin": [c["campaign_id"] for c in camps if c["spend"] and c["contribution"] is None]}
