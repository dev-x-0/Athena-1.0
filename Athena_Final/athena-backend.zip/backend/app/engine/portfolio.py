"""Per-campaign evaluation of the whole account (used by campaigns, alerts and insights)."""
from ..config import settings
from . import decision
from .metrics import campaign_stats, daily_series, latest_day, pct_change, roas_cv, stock_map, weekly_roas, window


def campaign_view(db, org_id, period="30d") -> dict:
    """Returns {'latest','window','prior','campaigns':[...with decision...]} or has_data False."""
    latest = latest_day(db, org_id)
    if not latest:
        return {"has_data": False, "campaigns": [], "latest": None}
    cfg = settings()
    s, e, bucket = window(latest, period)
    ps, pe, _ = window(latest, period, 1)
    cur, prior = campaign_stats(db, org_id, s, e), {c["campaign_id"]: c for c in campaign_stats(db, org_id, ps, pe)}
    stocks = stock_map(db, org_id)
    for c in cur:
        p = prior.get(c["campaign_id"], {})
        c["prior_roas"] = p.get("roas")
        c["roas_trend_pct"] = pct_change(c["roas"], p.get("roas"))
        c["stock_units"] = (stocks.get(c["sku"]) or {}).get("stock_level")
        c["weekly_roas"] = weekly_roas(daily_series(db, org_id, window(latest, "30d")[0], latest, c["campaign_id"]))
        d = decision.decide({
            "has_campaign": True, "data_days": c["days"], "roas": c["roas"] if c["spend"] else None,
            "roas_floor": cfg.roas_floor, "break_even_roas": c["break_even_roas"], "roas_trend_pct": c["roas_trend_pct"],
            "margin_pct": c["margin_pct"], "stock_units": c["stock_units"], "days_of_cover": None, "low_stock": cfg.low_stock,
            "baseline_spend": c["spend"]})
        c["decision"] = d
        c["weekly_cv"] = roas_cv(c["weekly_roas"])
    return {"has_data": True, "latest": latest, "window": {"start": s, "end": e, "bucket_days": bucket},
            "prior_window": {"start": ps, "end": pe}, "campaigns": cur, "prior": prior}
