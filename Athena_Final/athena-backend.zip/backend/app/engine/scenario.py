"""Custom inventory/advertising scenario analysis.

Pipeline per item: resolve inputs (user vs database) -> performance -> inventory -> projection ->
forecast -> decision -> explanation -> charts. Every number is a Metric with type + formula + sources.
Nothing is invented: missing inputs stay missing and are listed in data_gaps.
"""
from datetime import date, timedelta

from ..config import ENGINE_VERSION, settings
from ..db import one, rows
from . import alerts as alerts_engine
from . import decision as D
from .forecast import differs_from_trailing, linear_forecast
from .metrics import (ASSUMED, DERIVED, FORECAST, OBSERVED, campaign_stats, daily_series, latest_day, metric,
                      pct_change, roas_cv, safe_div, stock_map, weekly_roas, window)
from .provenance import build_references


class AnalysisInputError(ValueError):
    pass


def inr(v):
    return "n/a" if v is None else f"₹{v:,.0f}"


def _inp(field, user, dbval, dbsrc, unit, refs):
    base = {"field": field, "unit": unit}
    if user is not None:
        refs.add(f"user_input.{field}")
        return user, {**base, "value": user, "type": ASSUMED, "source": "user_input", "available": True}
    if dbval is not None:
        refs.add(dbsrc)
        return dbval, {**base, "value": dbval, "type": OBSERVED, "source": dbsrc, "available": True}
    return None, {**base, "value": None, "type": None, "source": None, "available": False}


def _chart(id_, type_, title, unit, x, series):
    return {"id": id_, "type": type_, "title": title, "unit": unit, "x": x, "series": series}


def analyze_item(db, org_id, it, ctx) -> dict:
    cfg, h, latest = ctx["cfg"], ctx["horizon"], ctx["latest"]
    floor = ctx["roas_floor"]
    refs, gaps, inputs = set(), [], []
    prod = one(db, "SELECT * FROM products WHERE org_id=? AND sku=?", (org_id, it.sku))
    inv = one(db, "SELECT * FROM inventory WHERE org_id=? AND sku=?", (org_id, it.sku))
    if not prod:
        gaps.append(f"SKU {it.sku} has no product record; only the values you typed are used.")

    # ---- campaign resolution ----
    camp = None
    if it.campaign_id:
        camp = one(db, "SELECT * FROM campaigns WHERE org_id=? AND campaign_id=?", (org_id, it.campaign_id))
        if not camp:
            raise AnalysisInputError(f"Unknown campaign_id '{it.campaign_id}'")
        if camp["sku"] and camp["sku"].lower() != it.sku.lower():
            gaps.append(f"Campaign {camp['campaign_id']} is linked to {camp['sku']}, not {it.sku}; its performance is used as a proxy.")
    else:
        cands = [c for c in ctx["campaigns"] if (c["sku"] or "").lower() == it.sku.lower()]
        if it.channel:
            cands = [c for c in cands if c["channel"].lower() == it.channel.lower()] or []
            if not cands:
                gaps.append(f"No campaign for {it.sku} on channel '{it.channel}'.")
        if cands:
            camp = max(cands, key=lambda c: (ctx["stats"].get(c["campaign_id"]) or {}).get("spend", 0))
            if len(cands) > 1:
                gaps.append(f"{len(cands)} campaigns promote {it.sku}; the highest-spend one ({camp['campaign_id']}) was used.")
    cs = ctx["stats"].get(camp["campaign_id"]) if camp else None
    has_ads = bool(cs and cs["spend"] > 0 and cs["days"] > 0)
    if not camp:
        gaps.append("No advertising campaign is linked to this SKU, so advertising metrics and projections are unavailable.")
    if camp:
        refs.update({"campaign_daily.spend", "campaign_daily.revenue", "campaign_daily.day", "campaigns.sku"})

    # ---- inputs: user value (ASSUMED) beats database value (OBSERVED); missing stays missing ----
    cur, r = _inp("current_inventory", it.current_inventory, inv["stock_level"] if inv else None, "inventory.stock_level", "units", refs); inputs.append(r)
    if it.planned_inventory is not None:
        planned, r = _inp("planned_inventory", it.planned_inventory, None, "", "units", refs)
    elif cur is not None:
        planned, r = cur, {"field": "planned_inventory", "unit": "units", "value": cur, "type": DERIVED, "source": "defaults to current_inventory (no change planned)", "available": True}
    else:
        planned, r = None, {"field": "planned_inventory", "unit": "units", "value": None, "type": None, "source": None, "available": False}
    inputs.append(r)
    price, r = _inp("selling_price", it.selling_price, prod and prod["selling_price"], "products.selling_price", "INR", refs); inputs.append(r)
    cost, r = _inp("unit_cost", it.unit_cost, prod and prod["unit_cost"], "products.unit_cost", "INR", refs); inputs.append(r)

    margin, margin_rec = None, {"field": "margin_pct", "unit": "%", "value": None, "type": None, "source": None, "available": False}
    if it.margin_pct is not None:
        margin, margin_rec = it.margin_pct, {"field": "margin_pct", "unit": "%", "value": it.margin_pct, "type": ASSUMED, "source": "user_input", "available": True}
        refs.add("user_input.margin_pct")
    elif price and cost is not None:
        margin = (price - cost) / price * 100
        margin_rec = {"field": "margin_pct", "unit": "%", "value": round(margin, 2), "type": DERIVED, "source": "(selling_price - unit_cost) / selling_price; gross, before fees", "available": True}
    elif prod and prod["margin_pct"] is not None:
        margin, margin_rec = prod["margin_pct"], {"field": "margin_pct", "unit": "%", "value": prod["margin_pct"], "type": OBSERVED, "source": "products.margin_pct", "available": True}
        refs.add("products.margin_pct")
    inputs.append(margin_rec)
    msrc = {ASSUMED: "user_input.margin_pct", DERIVED: "selling_price and unit_cost", OBSERVED: "products.margin_pct"}.get(margin_rec["type"], "margin (unknown)")
    if margin is None:
        gaps.append("Margin is unknown (no cost/price/margin supplied or stored): profit and break-even ROAS cannot be calculated, and Athena will not recommend scaling.")

    # demand: user (ASSUMED) or inferred from ad-attributed revenue (DERIVED lower bound, informational only)
    demand_user = it.expected_daily_demand
    demand_inferred = None
    if demand_user is None and price and has_ads and cs["revenue"] > 0:
        demand_inferred = cs["revenue"] / cs["days"] / price
    demand = demand_user if demand_user is not None else demand_inferred
    if demand_user is not None:
        refs.add("user_input.expected_daily_demand")
        inputs.append({"field": "expected_daily_demand", "unit": "units/day", "value": demand_user, "type": ASSUMED, "source": "user_input", "available": True})
    elif demand_inferred is not None:
        inputs.append({"field": "expected_daily_demand", "unit": "units/day", "value": round(demand_inferred, 2), "type": DERIVED,
                       "source": "avg daily ad-attributed revenue / selling_price (lower bound: excludes non-ad sales)", "available": True})
    else:
        inputs.append({"field": "expected_daily_demand", "unit": "units/day", "value": None, "type": None, "source": None, "available": False})
        gaps.append("Expected daily demand is unknown, so days of stock cover and demand-based revenue cannot be projected.")

    # ---- performance (observed / derived) ----
    perf, roas, trend, weekly, be = None, None, None, [], (100 / margin if margin and margin > 0 else None)
    series60 = []
    if camp and latest:
        s30, e30 = ctx["w30"][:2]
        prior = ctx["prior"].get(camp["campaign_id"]) or {}
        roas = cs["roas"] if has_ads else None
        trend = pct_change(roas, prior.get("roas"))
        start60 = (date.fromisoformat(latest) - timedelta(days=max(60, h) - 1)).isoformat()
        series60 = daily_series(db, org_id, start60, latest, camp["campaign_id"])
        weekly = weekly_roas([d for d in series60 if d["day"] >= s30])
        tr = f"{s30} to {e30}"
        perf = {"campaign": {"id": camp["campaign_id"], "name": camp["name"], "channel": camp["channel"], "sku": camp["sku"]},
                "window": {"start": s30, "end": e30, "days_with_data": cs["days"]}, "prior_window": {"start": ctx["wp"][0], "end": ctx["wp"][1]},
                "weekly_roas": weekly,
                "metrics": [
                    metric("ad_spend_30d", "Ad spend (last 30d)", cs["spend"], "INR", OBSERVED, "SUM(spend)", ["campaign_daily.spend"], time_range=tr),
                    metric("revenue_30d", "Attributed revenue (last 30d)", cs["revenue"], "INR", OBSERVED, "SUM(revenue)", ["campaign_daily.revenue"], time_range=tr),
                    metric("roas_30d", "ROAS (last 30d)", roas, "x", DERIVED, "revenue / advertising_spend", ["campaign_daily.revenue", "campaign_daily.spend"], time_range=tr),
                    metric("roas_prior_30d", "ROAS (prior 30d)", prior.get("roas"), "x", DERIVED, "revenue / advertising_spend", ["campaign_daily.revenue", "campaign_daily.spend"],
                           time_range=f"{ctx['wp'][0]} to {ctx['wp'][1]}"),
                    metric("roas_trend_pct", "ROAS change vs prior 30d", trend, "%", DERIVED, "(roas_30d - roas_prior_30d) / roas_prior_30d x 100", ["campaign_daily.revenue", "campaign_daily.spend"]),
                    metric("break_even_roas", "Break-even ROAS", be, "x", DERIVED, "100 / margin_pct", [msrc], note=None if be else "needs a known positive margin"),
                    metric("contribution_30d", "Contribution (last 30d)", cs["revenue"] * margin / 100 - cs["spend"] if margin is not None else None, "INR", DERIVED,
                           "revenue x margin_pct/100 - advertising_spend", ["campaign_daily.revenue", "campaign_daily.spend", msrc], time_range=tr),
                ]}
        if cs["days"] < 14:
            gaps.append(f"Only {cs['days']} days of campaign data in the last 30 days; trend and forecast are weak.")

    # ---- inventory ----
    change = planned - cur if planned is not None and cur is not None else None
    cover_planned = safe_div(planned, demand_user) if demand_user else None  # decision-grade only when user-supplied
    cover_info = safe_div(planned, demand) if demand else None
    demand_h = demand * h if demand else None
    shortfall = max(0.0, demand_h - planned) if demand_h is not None and planned is not None else None
    excess = max(0.0, planned - demand_h) if demand_h is not None and planned is not None else None
    if planned is None:
        risk = ("UNKNOWN", ["No inventory figure available."])
    elif planned <= 0:
        risk = ("CRITICAL", ["Planned stock is zero."])
    elif cover_info is not None:
        lv = "CRITICAL" if cover_info < D.CRITICAL_COVER_DAYS else "HIGH" if cover_info < 14 else "MEDIUM" if cover_info < h else "LOW"
        risk = (lv, [f"{cover_info:.1f} days of cover against a {h}-day horizon" + (" (demand inferred from ad revenue - treat as an upper bound)" if demand_user is None else "")])
    elif planned < cfg.low_stock:
        risk = ("HIGH", [f"{planned} units is below the {cfg.low_stock}-unit low-stock threshold; demand unknown."])
    else:
        risk = ("UNKNOWN", [f"{planned} units; demand unknown so cover cannot be judged."])
    overstock = cover_info is not None and cover_info > 90
    inv_state = {
        "current": cur, "planned": planned, "change": change, "demand_per_day": None if demand is None else round(demand, 2),
        "demand_basis": "user_input" if demand_user is not None else ("derived_from_ad_revenue" if demand_inferred is not None else None),
        "days_of_cover": None if cover_info is None else round(cover_info, 1), "shortfall_units": None if shortfall is None else round(shortfall, 1),
        "excess_units": None if excess is None else round(excess, 1), "overstock": overstock,
        "risk": {"level": risk[0], "reasons": risk[1]},
        "exposure_at_cost": None if planned is None or cost is None else round(planned * cost, 2),
        "exposure_at_retail": None if planned is None or not price else round(planned * price, 2),
    }
    if inv:
        refs.add("inventory.stock_level")

    # ---- projection ----
    baseline_daily = cs["spend"] / cs["days"] if has_ads else None
    baseline_h = baseline_daily * h if baseline_daily is not None else None
    if it.planned_ad_spend is not None or it.planned_daily_spend is not None:
        planned_spend = it.planned_ad_spend if it.planned_ad_spend is not None else it.planned_daily_spend * h
        f = "planned_ad_spend" if it.planned_ad_spend is not None else "planned_daily_spend"
        refs.add(f"user_input.{f}")
        inputs.append({"field": "planned_ad_spend", "unit": "INR", "value": round(planned_spend, 2), "type": ASSUMED, "source": "user_input" + (f" ({it.planned_daily_spend}/day x {h} days)" if f == "planned_daily_spend" else ""), "available": True})
        eff = planned_spend
    elif baseline_h is not None:
        planned_spend = None
        eff = baseline_h
        inputs.append({"field": "planned_ad_spend", "unit": "INR", "value": round(eff, 2), "type": DERIVED, "source": "defaults to trailing run-rate x horizon", "available": True})
    else:
        planned_spend = eff = None
        inputs.append({"field": "planned_ad_spend", "unit": "INR", "value": None, "type": None, "source": None, "available": False})
    roas_vals = [v for v in weekly if v is not None]
    roas_low, roas_high = (min(roas_vals), max(roas_vals)) if len(roas_vals) >= 3 else (None, None)
    ad_rev = ad_low = ad_high = None
    if eff is not None and roas is not None:
        run, extra = min(eff, baseline_h), max(0.0, eff - baseline_h)
        ad_rev = run * roas + extra * (roas_low if roas_low is not None else roas)
        if roas_low is not None:
            ad_low = min(eff * roas_low, ad_rev)
            ad_high = max(run * roas_high + extra * roas, ad_rev)
        refs.add("method.scenario_revenue")
    cap_rev = planned * price if planned is not None and price else None
    stock_limited = False
    if cap_rev is not None and ad_rev is not None and ad_rev > cap_rev:
        stock_limited = True
    capped = lambda v: None if v is None else (min(v, cap_rev) if cap_rev is not None else v)  # noqa: E731
    ad_rev_c, ad_low_c, ad_high_c = capped(ad_rev), capped(ad_low), capped(ad_high)

    if demand_user is not None and price and planned is not None:
        units_sold = min(demand_user * h, planned)
        revenue, rev_basis = units_sold * price, "demand_x_price"
    elif ad_rev_c is not None and price:
        units_sold, revenue, rev_basis = ad_rev_c / price, ad_rev_c, "ad_attributed_capped_by_stock"
    else:
        units_sold = revenue = rev_basis = None
    if revenue is None and eff is not None:
        gaps.append("Revenue cannot be projected without a selling price" + (" and expected demand." if demand_user is None else "."))
    procurement = (max(0, change) * cost if cost is not None else None) if change is not None and change > 0 else (0.0 if change is not None else None)
    if change is not None and change > 0 and cost is None:
        gaps.append(f"Procuring {change} units cannot be costed: unit cost is unknown.")
    cogs = units_sold * cost if units_sold is not None and cost is not None else None
    expenses = (eff + procurement) if eff is not None and procurement is not None else None
    if revenue is not None and cogs is not None and eff is not None:
        profit, profit_f = revenue - cogs - eff, "revenue - cogs - ad_spend"
    elif revenue is not None and margin is not None and eff is not None:
        profit, profit_f = revenue * margin / 100 - eff, "revenue x margin_pct/100 - ad_spend"
    else:
        profit, profit_f = None, None
    ad_req = safe_div(revenue, roas) if revenue is not None and roas else None
    max_useful = safe_div(cap_rev, roas) if cap_rev is not None and roas else None
    refs.add("method.break_even_roas") if be else None
    src_in = ["scenario inputs"]
    P = []  # projection metrics
    P.append(metric("planned_ad_spend", "Advertising spend over horizon", eff, "INR", ASSUMED if planned_spend is not None else DERIVED,
                    "user-entered" if planned_spend is not None else "trailing daily spend x horizon_days", ["user_input.planned_ad_spend"] if planned_spend is not None else ["campaign_daily.spend"],
                    {"horizon_days": h}))
    P.append(metric("baseline_ad_spend", "Trailing run-rate spend over horizon", baseline_h, "INR", DERIVED, "avg daily spend (last 30d) x horizon_days", ["campaign_daily.spend"], {"horizon_days": h}))
    bi = None if eff is None or baseline_h is None else {"baseline": round(baseline_h, 2), "planned": round(eff, 2), "delta": round(eff - baseline_h, 2), "delta_pct": pct_change(eff, baseline_h)}
    if bi and bi["delta_pct"] is not None and bi["delta_pct"] > 50:
        gaps.append(f"Planned spend is {bi['delta_pct']:.0f}% above the trailing run-rate; incremental spend is valued at the weakest weekly ROAS because returns may diminish.")
    P.append(metric("ad_attributed_revenue", "Ad-attributed revenue (base)", ad_rev_c, "INR", FORECAST, "min(spend, run-rate) x ROAS + excess x weakest weekly ROAS, capped by stock value",
                    ["campaign_daily.revenue", "campaign_daily.spend", "method.scenario_revenue"], {"roas_30d": roas, "roas_low": roas_low, "roas_high": roas_high, "spend": eff},
                    note="low/high use weakest/strongest weekly ROAS" if roas_low is not None else "range unavailable (needs 3+ weeks of data)",
                    low=None if ad_low_c is None else round(ad_low_c, 2), high=None if ad_high_c is None else round(ad_high_c, 2), stock_limited=stock_limited))
    P.append(metric("projected_revenue", "Projected revenue", revenue, "INR", FORECAST,
                    "min(demand x horizon, planned_stock) x price" if rev_basis == "demand_x_price" else "ad-attributed revenue capped by planned_stock x price",
                    ["user_input.expected_daily_demand", "user_input.selling_price"] if rev_basis == "demand_x_price" else ["campaign_daily.revenue"],
                    {"basis": rev_basis, "units_sold": None if units_sold is None else round(units_sold, 1), "price": price}, note="inputs marked ASSUMED in `inputs`" if rev_basis == "demand_x_price" else None))
    P.append(metric("procurement_cost", "Procurement cost", procurement, "INR", DERIVED, "max(0, planned_inventory - current_inventory) x unit_cost", ["inventory.stock_level", "unit_cost"], {"units": None if change is None else max(0, change), "unit_cost": cost}))
    P.append(metric("cogs", "Cost of goods sold", cogs, "INR", FORECAST, "units_sold x unit_cost", ["unit_cost"], {"units_sold": None if units_sold is None else round(units_sold, 1), "unit_cost": cost}))
    P.append(metric("projected_expenses", "Projected expenses (ad spend + procurement)", expenses, "INR", FORECAST, "ad_spend + procurement_cost", ["planned_ad_spend", "procurement_cost"]))
    P.append(metric("projected_profit", "Projected gross profit after ads", profit, "INR", FORECAST, profit_f, ["projected_revenue", "cogs" if profit_f and "cogs" in profit_f else "margin_pct", "planned_ad_spend"],
                    note=None if profit is not None else "needs price and (unit cost or margin)"))
    P.append(metric("advertising_requirement", "Ad spend needed to deliver projected revenue", ad_req, "INR", DERIVED, "projected_revenue / roas_30d", ["campaign_daily.revenue", "campaign_daily.spend"],
                    note="upper bound: assumes all projected revenue is acquired through this campaign at observed ROAS"))
    P.append(metric("max_stock_supported_spend", "Most spend the planned stock can convert", max_useful, "INR", DERIVED, "planned_inventory x price / roas_30d", ["inventory.stock_level", "selling_price", "campaign_daily.revenue"]))
    if ad_rev_c is not None and margin is not None and eff is not None:
        P.append(metric("projected_ad_contribution", "Projected contribution from ad revenue", ad_rev_c * margin / 100 - eff, "INR", FORECAST, "ad_attributed_revenue x margin_pct/100 - ad_spend", ["ad_attributed_revenue", msrc]))
    P.append(metric("inventory_exposure_at_cost", "Inventory capital exposure", inv_state["exposure_at_cost"], "INR", DERIVED, "planned_inventory x unit_cost", ["inventory.stock_level", "unit_cost"]))

    # ---- forecast of campaign revenue (existing trend) ----
    fc = fc_change = None
    if camp and series60:
        fc = linear_forecast([{"day": d["day"], "value": d["revenue"]} for d in series60], h)
        if fc:
            refs.add("method.linear_trend_forecast")
            trail = [d for d in series60 if d["day"] > (date.fromisoformat(latest) - timedelta(days=h)).isoformat()]
            fc_change_raw, fc_sig = None, False
            if len(trail) >= 0.8 * h:
                tsum = sum(d["revenue"] for d in trail)
                fc_change_raw = pct_change(fc["total"]["base"], tsum)
                fc_sig = differs_from_trailing(fc, tsum)
                fc_change = fc_change_raw if fc_sig else None   # only act on changes beyond normal variation
            fc["change_vs_trailing_pct"], fc["change_is_significant"] = fc_change_raw, fc_sig
            if h > 60:
                fc["extrapolation_warning"] = "Horizon is long relative to the 30-day fit window; treat as indicative only."
        else:
            gaps.append("Fewer than 14 observed days: no trend forecast produced.")

    # ---- decision ----
    stock_for_decision = planned
    ev = {"has_campaign": has_ads, "data_days": cs["days"] if cs else 0, "roas": roas, "roas_floor": floor, "break_even_roas": be,
          "roas_trend_pct": trend, "margin_pct": margin, "stock_units": stock_for_decision, "days_of_cover": cover_planned,
          "low_stock": cfg.low_stock, "horizon_days": h, "planned_spend": planned_spend, "baseline_spend": baseline_h, "max_useful_spend": max_useful,
          "forecast_change_pct": fc_change}
    dec = D.decide(ev)
    refs.add("method.decision_rules")
    conf = D.confidence(data_days=ev["data_days"], margin_known=margin is not None, weekly_cv=roas_cv(weekly),
                        demand_known=demand_user is not None, price_known=bool(price), has_campaign=has_ads)

    # ---- explanation: the six questions ----
    name = it.product_name or (prod["name"] if prod else it.sku)
    if has_ads:
        what = (f"Over {ctx['w30'][0]} to {ctx['w30'][1]}, {camp['name']} ({camp['channel']}) spent {inr(cs['spend'])} and returned {inr(cs['revenue'])} "
                f"attributed revenue: ROAS {roas:.2f}x" + (f" versus {ctx['prior'][camp['campaign_id']]['roas']:.2f}x in the prior 30 days." if (ctx['prior'].get(camp['campaign_id']) or {}).get('roas') else "."))
    else:
        what = f"No advertising history is linked to {name} ({it.sku}); Athena can only assess inventory."
    pred_parts = []
    if ad_rev_c is not None:
        rng = f" (range {inr(ad_low_c)} to {inr(ad_high_c)})" if ad_low_c is not None else ""
        pred_parts.append(f"At {inr(eff)} ad spend over {h} days" + ("" if planned_spend is not None else " (your trailing run-rate - no spend entered)") + f" Athena forecasts {inr(ad_rev_c)} ad-attributed revenue{rng}" + (", limited by available stock" if stock_limited else "") + ".")
    if revenue is not None and rev_basis == "demand_x_price":
        pred_parts.append(f"With your demand assumption and stock, projected sales revenue is {inr(revenue)}" + (f" and projected profit after ads {inr(profit)}." if profit is not None else "."))
    if cover_info is not None:
        pred_parts.append(f"Stock covers {cover_info:.1f} days of demand" + ("" if demand_user is not None else " (demand inferred, upper bound)") + ".")
    if not pred_parts:
        pred_parts.append("Insufficient data to project: " + ("; ".join(g for g in gaps[:2]) if gaps else "inputs missing") )
    todo = f"{dec['label']}" + (f" ({dec['spend_change_pct']:+d}% spend)" if dec["spend_change_pct"] else "") + "."
    if inv_state["shortfall_units"]:
        todo += f" Stock short by about {inv_state['shortfall_units']:.0f} units over the horizon: replenish."
    explanation = {"what_happened": what, "why_it_happened": dec["rationale"] + dec["conflicts"], "data_support": sorted(refs),
                   "prediction": " ".join(pred_parts), "recommended_action": todo,
                   "why_recommended": dec["rationale"][0] if dec["rationale"] else "", "reason_codes": dec["reason_codes"]}

    # ---- charts ----
    charts = []
    if series60 and camp:
        obs = series60[-60:]
        x = [d["day"] for d in obs] + (fc["dates"] if fc else [])
        pad = [None] * (len(fc["dates"]) if fc else 0)
        sers = [{"name": "Revenue (observed)", "kind": "observed", "values": [d["revenue"] for d in obs] + pad},
                {"name": "Ad spend (observed)", "kind": "observed", "values": [d["spend"] for d in obs] + pad}]
        if fc:
            lead = [None] * len(obs)
            sers += [{"name": "Revenue (forecast)", "kind": "forecast", "values": lead + fc["base"]},
                     {"name": "Forecast low", "kind": "forecast_band", "values": lead + fc["low"]},
                     {"name": "Forecast high", "kind": "forecast_band", "values": lead + fc["high"]}]
        charts.append(_chart("trajectory", "trajectory", f"{camp['name']}: revenue and spend with forecast", "INR", x, sers))
    if demand and planned is not None:
        days_x = list(range(0, h + 1))
        s = [{"name": "Planned stock", "kind": "forecast", "values": [max(0, round(planned - demand * d, 1)) for d in days_x]}]
        if cur is not None and cur != planned:
            s.append({"name": "Current stock", "kind": "forecast", "values": [max(0, round(cur - demand * d, 1)) for d in days_x]})
        charts.append(_chart("stock_projection", "line", "Stock burn-down at expected demand", "units", [f"day {d}" for d in days_x], s))
    if revenue is not None and (cogs is not None or margin is not None):
        labels, vals = ["Revenue"], [revenue]
        if cogs is not None:
            labels.append("COGS"); vals.append(cogs)
        if eff is not None:
            labels.append("Ad spend"); vals.append(eff)
        if profit is not None:
            labels.append("Profit"); vals.append(profit)
        charts.append(_chart("economics", "bar", "Projected economics over horizon", "INR", labels, [{"name": "INR", "kind": "forecast", "values": [round(v, 2) for v in vals]}]))
    return {"sku": it.sku, "product_name": name, "campaign": perf["campaign"] if perf else None, "inputs": inputs, "performance": perf,
            "inventory": inv_state, "projection": {"horizon_days": h, "metrics": P, "budget_impact": bi, "revenue_basis": rev_basis,
                                                   "campaign_revenue_forecast": fc, "campaign_revenue_forecast_change_pct": fc_change,
                                                   "campaign_revenue_forecast_change_is_significant": bool(fc and fc.get("change_is_significant"))},
            "decision": {**dec, "confidence": conf}, "explanation": explanation, "charts": charts, "data_gaps": gaps,
            "_refs": refs, "_eff": eff, "_ad_rev": ad_rev_c, "_revenue": revenue, "_expenses": expenses, "_profit": profit, "_roas": roas, "_be": be,
            "_cid": camp["campaign_id"] if camp else None}


def run(db, org_id, req) -> dict:
    cfg = settings()
    latest = latest_day(db, org_id)
    floor = (req.assumptions.roas_floor if req.assumptions and req.assumptions.roas_floor else cfg.roas_floor)
    ctx = {"cfg": cfg, "horizon": req.horizon_days, "latest": latest, "roas_floor": floor,
           "campaigns": rows(db, "SELECT * FROM campaigns WHERE org_id=?", (org_id,)), "stats": {}, "prior": {}, "w30": None, "wp": None}
    if latest:
        ctx["w30"], ctx["wp"] = window(latest, "30d"), window(latest, "30d", 1)
        ctx["stats"] = {c["campaign_id"]: c for c in campaign_stats(db, org_id, *ctx["w30"][:2])}
        ctx["prior"] = {c["campaign_id"]: c for c in campaign_stats(db, org_id, *ctx["wp"][:2])}
    items = [analyze_item(db, org_id, it, ctx) for it in req.items]
    refs = set().union(*(i["_refs"] for i in items))
    tr = {}
    if latest:
        for k in ("campaign_daily.spend", "campaign_daily.revenue", "campaign_daily.day", "method.linear_trend_forecast"):
            tr[k] = f"{ctx['w30'][0]} to {ctx['w30'][1]} (prior window {ctx['wp'][0]} to {ctx['wp'][1]})"
    for k in ("products.margin_pct", "products.selling_price", "products.unit_cost", "campaigns.sku", "campaigns.channel"):
        tr[k] = "current record at time of analysis"
    stamp = (one(db, "SELECT MAX(updated_at) AS t FROM inventory WHERE org_id=?", (org_id,)) or {}).get("t")
    tr["inventory.stock_level"] = f"snapshot updated {stamp}" if stamp else None
    references = build_references(db, org_id, refs, tr)

    skus = {i["sku"].lower() for i in items}
    cids = {i["_cid"] for i in items if i["_cid"]}
    rel_alerts = [a for a in alerts_engine.generate(db, org_id) if (a["sku"] or "").lower() in skus or a["campaign_id"] in cids]

    acts = {}
    for i in items:
        acts[i["decision"]["action"]] = acts.get(i["decision"]["action"], 0) + 1
    top = max(items, key=lambda i: D.SEVERITY[i["decision"]["action"]])["decision"]["action"]
    n = len(items)
    def total(key):
        vals = [i[key] for i in items if i[key] is not None]
        return (sum(vals) if vals else None), len(vals)
    kpis = []
    for key, label, src_key in (("_eff", "Total advertising spend", "planned_ad_spend"), ("_revenue", "Total projected revenue", "projected_revenue"),
                                ("_expenses", "Total projected expenses", "projected_expenses"), ("_profit", "Total projected profit after ads", "projected_profit")):
        v, k = total(key)
        kpis.append(metric(src_key + "_total", label, v, "INR", FORECAST, f"sum of per-SKU {src_key}", [src_key],
                           note=None if k == n else f"covers {k} of {n} SKUs; the rest lack the inputs needed"))
    both = [i for i in items if i["_eff"] is not None and i["_ad_rev"] is not None]
    kpis.append(metric("expected_blended_roas", "Expected blended ROAS", safe_div(sum(i["_ad_rev"] for i in both), sum(i["_eff"] for i in both)), "x", FORECAST, "sum(ad_attributed_revenue) / sum(ad_spend) over SKUs with both", ["ad_attributed_revenue", "planned_ad_spend"],
                       note=None if len(both) == n else f"covers {len(both)} of {n} SKUs"))
    charts = []
    spends = [(i["campaign"]["name"] if i["campaign"] else i["sku"], i["_eff"]) for i in items if i["_eff"]]
    if len(spends) >= 2:
        charts.append(_chart("spend_allocation", "donut", "Planned spend allocation", "INR", [s[0] for s in spends], [{"name": "Spend", "kind": "forecast", "values": [round(s[1], 2) for s in spends]}]))
    cmp_items = [i for i in items if i["_eff"] is not None and i["_ad_rev"] is not None]
    if cmp_items:
        charts.append(_chart("spend_vs_revenue", "bar", "Planned spend vs forecast ad revenue", "INR", [i["sku"] for i in cmp_items],
                             [{"name": "Ad spend", "kind": "forecast", "values": [round(i["_eff"], 2) for i in cmp_items]}, {"name": "Ad revenue", "kind": "forecast", "values": [round(i["_ad_rev"], 2) for i in cmp_items]}]))
    roas_items = [i for i in items if i["_roas"] is not None]
    if roas_items:
        charts.append(_chart("roas_vs_break_even", "bar", "Observed ROAS vs break-even ROAS", "x", [i["sku"] for i in roas_items],
                             [{"name": "Observed ROAS", "kind": "observed", "values": [round(i["_roas"], 3) for i in roas_items]}, {"name": "Break-even ROAS", "kind": "derived", "values": [None if i["_be"] is None else round(i["_be"], 3) for i in roas_items]},
                              {"name": "ROAS floor", "kind": "policy", "values": [floor] * len(roas_items)}]))
    allocation = []
    tot_eff = sum(i["_eff"] for i in items if i["_eff"]) or 0
    for i in items:
        if i["_eff"] is not None and tot_eff:
            cpr = None if i["_roas"] is None or i["_be"] is None else round(i["_roas"] / i["_be"] - 1, 3)
            allocation.append({"sku": i["sku"], "campaign_id": i["_cid"], "planned_spend": round(i["_eff"], 2), "share_pct": round(i["_eff"] / tot_eff * 100, 1),
                               "action": i["decision"]["action"], "profit_per_rupee": cpr,
                               "note": "profit_per_rupee = ROAS / break-even ROAS - 1 (positive = profitable at the margin)"})
    gaps = sorted({f"{i['sku']}: {g}" for i in items for g in i["data_gaps"]})
    conf_scores = [i["decision"]["confidence"]["score"] for i in items]
    avg = round(sum(conf_scores) / len(conf_scores), 2)
    level = "HIGH" if avg >= 0.75 else "MEDIUM" if avg >= 0.5 else "LOW"
    headline = f"{n} SKU{'s' if n > 1 else ''} analysed over {req.horizon_days} days: " + ", ".join(f"{v} {k}" for k, v in sorted(acts.items(), key=lambda kv: -D.SEVERITY[kv[0]]))
    for i in items:
        for k in [k for k in i if k.startswith("_")]:
            del i[k]
    return {"engine_version": ENGINE_VERSION, "horizon_days": req.horizon_days, "data_as_of": latest, "roas_floor": floor,
            "summary": {"headline": headline, "items_analyzed": n, "actions": acts, "top_priority_action": top,
                        "confidence": {"level": level, "score": avg, "basis": "mean of per-SKU data-sufficiency scores (heuristic)"}, "kpis": kpis},
            "items": items, "allocation": allocation, "alerts": rel_alerts, "charts": charts, "references": references, "data_gaps": gaps,
            "legend": {"OBSERVED": "read directly from your data", "DERIVED": "calculated from observed/assumed values",
                       "FORECAST": "predicted by an Athena method", "ASSUMED": "typed in by you for this scenario"}}
