"""Alerts generated from data on demand. Nothing is hard-coded; only acknowledgement state is stored."""
from statistics import mean, pstdev

from ..config import settings
from ..db import rows
from .forecast import differs_from_trailing, linear_forecast
from .metrics import campaign_stats, daily_series, latest_day, pct_change, window, stock_map, safe_div

SEV_ORDER = {"CRITICAL": 0, "WARNING": 1, "INFO": 2}


def generate(db, org_id) -> list[dict]:
    latest = latest_day(db, org_id)
    cfg, found = settings(), []
    stocks = stock_map(db, org_id)
    names = {r["sku"]: r["name"] for r in rows(db, "SELECT sku, name FROM products WHERE org_id=?", (org_id,))}
    linked = {r["sku"]: r["campaign_id"] for r in rows(db, "SELECT sku, MIN(campaign_id) AS campaign_id FROM campaigns WHERE org_id=? AND sku IS NOT NULL GROUP BY sku", (org_id,))}

    def add(sev, cat, title, desc, cid=None, sku=None, stats=None, evidence=()):
        found.append({"code": f"{cat}:{cid or sku}", "severity": sev, "category": cat, "title": title,
                      "description": desc, "campaign_id": cid, "sku": sku, "stats": stats or {}, "evidence": list(evidence)})

    for sku, st in stocks.items():  # critical inventory (independent of ad history)
        if st["stock_level"] <= 0 or st["stock_level"] < cfg.low_stock:
            who = names.get(sku, sku)
            add("CRITICAL", "critical_inventory", f"{who}: critical inventory",
                f"Only {st['stock_level']} units on hand (threshold {cfg.low_stock}).", linked.get(sku), sku,
                {"stock_units": st["stock_level"], "threshold": cfg.low_stock}, ["inventory.stock_level"])
    if latest:
        s30, e30, _ = window(latest, "30d")
        ps, pe, _ = window(latest, "30d", 1)
        cur, prev = campaign_stats(db, org_id, s30, e30), {c["campaign_id"]: c for c in campaign_stats(db, org_id, ps, pe)}
        total_spend = sum(c["spend"] for c in cur) or 0
        for c in cur:
            if not c["spend"]:
                continue
            cid, roas = c["campaign_id"], c["roas"]
            st = {"roas": round(roas, 2), "spend": c["spend"], "stock_units": (stocks.get(c["sku"]) or {}).get("stock_level")}
            if roas < cfg.roas_floor:
                add("WARNING", "low_roas", f"{cid}: low ROAS", f"ROAS is {roas:.2f}x, below the {cfg.roas_floor:.2f}x floor.", cid, c["sku"], st,
                    ["campaign_daily.revenue", "campaign_daily.spend"])
            p = prev.get(cid, {}).get("roas")
            if p and roas < p * 0.8:
                add("WARNING", "roas_deterioration", f"{cid}: ROAS deterioration",
                    f"ROAS fell {(1 - roas / p) * 100:.1f}% versus the previous 30 days ({p:.2f}x to {roas:.2f}x).", cid, c["sku"],
                    {**st, "prior_roas": round(p, 2)}, ["campaign_daily.revenue", "campaign_daily.spend"])
            m = c["margin_pct"]
            if m is not None and m < 15:
                add("WARNING", "weak_margin", f"{cid}: weak margin",
                    f"{c['product_name']} has a {m:.1f}% margin; break-even needs {100 / m:.1f}x ROAS" + (f" and current ROAS is {roas:.2f}x." if m > 0 else "."),
                    cid, c["sku"], {**st, "margin_pct": m}, ["products.margin_pct", "method.break_even_roas"])
            if c["contribution"] is not None and c["contribution"] < -0.05 * c["spend"] and total_spend and c["spend"] / total_spend >= 0.15:
                add("WARNING", "excessive_spend", f"{cid}: heavy spend, negative contribution",
                    f"{c['spend'] / total_spend * 100:.0f}% of account spend produced a contribution of {c['contribution']:,.0f}.", cid, c["sku"],
                    {**st, "contribution": c["contribution"], "spend_share_pct": round(c["spend"] / total_spend * 100, 1)},
                    ["campaign_daily.spend", "products.margin_pct"])
            # abnormal performance: last 7d daily ROAS vs the preceding 23 days
            ser = [d for d in daily_series(db, org_id, s30, e30, cid) if d["spend"] > 0]
            if len(ser) >= 20:
                roas_d = [d["revenue"] / d["spend"] for d in ser]
                base, last7 = roas_d[:-7], roas_d[-7:]
                sd = pstdev(base)
                if sd > 0:
                    z = (mean(last7) - mean(base)) / (sd / 7 ** 0.5)
                    if abs(z) >= 3:
                        add("INFO", "abnormal_performance", f"{cid}: abnormal ROAS",
                            f"Last-7-day ROAS {mean(last7):.2f}x is {abs(z):.1f} standard errors {'above' if z > 0 else 'below'} the prior {mean(base):.2f}x.",
                            cid, c["sku"], {**st, "z_score": round(z, 1)}, ["campaign_daily.revenue", "campaign_daily.spend"])
        tot = [{"day": d["day"], "value": d["revenue"]} for d in daily_series(db, org_id, window(latest, "30d")[0], latest)]
        fc = linear_forecast(tot, 7)
        if fc and len(tot) >= 14:
            last7 = sum(t["value"] for t in tot[-7:])
            ch = pct_change(fc["total"]["base"], last7)
            if ch is not None and ch <= -10 and differs_from_trailing(fc, last7):
                add("WARNING", "forecast_risk", "Revenue forecast declining",
                    f"Linear trend forecasts {fc['total']['base']:,.0f} revenue over the next 7 days, {abs(ch):.1f}% below the last 7 days.",
                    None, None, {"forecast_7d": fc["total"]["base"], "last_7d": round(last7, 2), "change_pct": ch},
                    ["campaign_daily.revenue", "method.linear_trend_forecast"])
    acked = {r["code"] for r in rows(db, "SELECT code FROM alert_ack WHERE org_id=?", (org_id,))}
    for a in found:
        a["acknowledged"] = a["code"] in acked
    found.sort(key=lambda a: (SEV_ORDER[a["severity"]], a["code"]))
    return found
