"""Provenance catalogue: for every field/method Athena relies on - what it is, why it is used, and its limits.

Built into the backend (not decorative UI text). Analyses record the catalogue keys they actually used.
"""
from ..db import rows

ORIGIN_LABELS = {
    "sample_seed": "Internal synthetic sample data (not real business data)",
    "user_import": "Supplied by your company via CSV import",
    "user_entry": "Entered manually in Athena",
    "legacy_dump": "Preserved legacy dataset (original public/third-party source not documented)",
    "user_input": "Scenario value typed in by the analyst for this run",
}

CATALOG = {
    "campaign_daily.spend": dict(table="campaign_daily", field="spend", purpose="Advertising expenditure",
        transformation="Summed per campaign (and per channel/total) over the stated time range",
        reason="Denominator of ROAS and the cost side of campaign contribution",
        limitations="Daily granularity; platform-reported spend, not reconciled to invoices"),
    "campaign_daily.revenue": dict(table="campaign_daily", field="revenue", purpose="Attributed revenue",
        transformation="Summed per campaign over the time range; also fitted with a linear trend for forecasts",
        reason="Numerator of ROAS; basis for revenue trend and forecast",
        limitations="Direct-attribution revenue only - understates total sales if other channels assist"),
    "campaign_daily.day": dict(table="campaign_daily", field="day", purpose="Time axis",
        transformation="Windowed to the last N days ending at the latest observed day; prior window = the N days before",
        reason="Defines comparison periods and trend", limitations="Windows end at the latest data day, not today"),
    "campaigns.sku": dict(table="campaigns", field="sku", purpose="Links a campaign to the product it promotes",
        transformation="Join campaigns.sku = products.sku", reason="Lets ad performance be judged against product margin and stock",
        limitations="One SKU per campaign; multi-product campaigns are not split"),
    "campaigns.channel": dict(table="campaigns", field="channel", purpose="Ad channel / platform",
        transformation="Group-by for channel mix", reason="Channel comparison and allocation", limitations="Free-text label"),
    "products.margin_pct": dict(table="products", field="margin_pct", purpose="Net margin % after COGS and fees",
        transformation="Contribution = revenue x margin% - spend; break-even ROAS = 100 / margin%",
        reason="Revenue growth is not profit: margin decides whether a ROAS is actually profitable",
        limitations="Single margin per SKU as supplied; not time-varying; blank when unknown"),
    "products.selling_price": dict(table="products", field="selling_price", purpose="Unit selling price",
        transformation="Used to convert units to revenue", reason="Revenue projection for inventory scenarios",
        limitations="Often blank - scenario must supply it, otherwise revenue in units cannot be projected"),
    "products.unit_cost": dict(table="products", field="unit_cost", purpose="Unit cost of goods",
        transformation="procurement = units to buy x unit cost; COGS = units sold x unit cost",
        reason="Expense and profit projection", limitations="Often blank - scenario must supply it"),
    "inventory.stock_level": dict(table="inventory", field="stock_level", purpose="Units on hand",
        transformation="Compared with demand (days of cover) or the low-stock threshold",
        reason="Advertising must not outrun stock", limitations="Point-in-time snapshot; no warehouse split or inbound stock"),
    "method.linear_trend_forecast": dict(kind="method", purpose="Forecast of revenue/spend",
        transformation="OLS straight line over the last 30 observed days; ~95% prediction interval including trend uncertainty",
        reason="Simple, inspectable and reproducible", limitations="Ignores seasonality and diminishing returns; needs >= 14 observed days"),
    "method.break_even_roas": dict(kind="method", purpose="ROAS needed to cover product margin",
        transformation="100 / margin%", reason="Ties ad efficiency to product economics", limitations="Requires a known positive margin"),
    "method.decision_rules": dict(kind="method", purpose="SCALE / HOLD / REDUCE / PAUSE / REVIEW",
        transformation="Ordered rules over ROAS vs floor and break-even, trend, margin, stock cover and forecast; conflicts are surfaced, not hidden",
        reason="Multi-evidence decision, never a single metric", limitations="Rule thresholds are policy, not learned; spend-change steps are policy steps"),
    "method.scenario_revenue": dict(kind="method", purpose="Scenario revenue and spend response",
        transformation="Ad revenue = spend x observed ROAS; spend above the trailing run-rate is valued at the weakest weekly ROAS; capped by stock value",
        reason="Avoids assuming returns scale linearly", limitations="Constant-return assumption below run-rate; no saturation curve"),
}

USER_FIELDS = {
    "current_inventory": "Units on hand you entered", "planned_inventory": "Target stock level after replenishment/sell-down",
    "selling_price": "Unit selling price", "unit_cost": "Unit cost of goods", "margin_pct": "Net margin %",
    "expected_daily_demand": "Expected units sold per day", "planned_ad_spend": "Total ad spend over the horizon",
    "planned_daily_spend": "Daily ad spend", "horizon_days": "Planning horizon",
}


def origin_for(db, org_id, table) -> list[str]:
    if table not in {"campaign_daily", "campaigns", "products", "inventory"}:
        return []
    return [r["source"] for r in rows(db, f"SELECT DISTINCT source FROM {table} WHERE org_id=?", (org_id,))]


def build_references(db, org_id, keys, time_ranges: dict | None = None) -> list[dict]:
    """Expand catalogue keys (and user_input.<field> keys) into full reference entries."""
    out, tr = [], time_ranges or {}
    for key in sorted(set(keys)):
        if key.startswith("user_input."):
            f = key.split(".", 1)[1]
            out.append({"key": key, "kind": "user_input", "source": "User-supplied scenario input", "table": None, "field": f,
                        "purpose": USER_FIELDS.get(f, f), "transformation": "Used as entered, labelled ASSUMED",
                        "reason": "Athena does not invent business values; you supplied this one", "time_range": f"horizon of this run",
                        "limitations": "Not verified against any database record", "origin": ["user_input"],
                        "origin_labels": [ORIGIN_LABELS["user_input"]]})
        elif key in CATALOG:
            c = CATALOG[key]
            origins = origin_for(db, org_id, c.get("table"))
            out.append({"key": key, "kind": c.get("kind", "dataset_field"), "source": c.get("table") or "Athena method",
                        "table": c.get("table"), "field": c.get("field"), "purpose": c["purpose"],
                        "transformation": c["transformation"], "reason": c["reason"], "time_range": tr.get(key),
                        "limitations": c["limitations"], "origin": origins,
                        "origin_labels": [ORIGIN_LABELS.get(o, o) for o in origins]})
    return out
