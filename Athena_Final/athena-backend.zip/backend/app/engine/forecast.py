"""Forecasting: transparent OLS linear trend with an approximate interval. No hidden models."""
from datetime import date, timedelta
from math import sqrt

MIN_POINTS = 14


def linear_forecast(series: list[dict], horizon: int, window_days: int = 30, min_points: int = MIN_POINTS) -> dict | None:
    """series: [{'day': 'YYYY-MM-DD', 'value': float}] sorted by day.

    Fits y = a + b*x over the last `window_days` calendar days (x = real day offset, so gaps are not
    zero-filled). Returns None when there are fewer than `min_points` observed days.
    """
    if not series:
        return None
    last = date.fromisoformat(series[-1]["day"])
    cutoff = last - timedelta(days=window_days - 1)
    pts = [(date.fromisoformat(s["day"]), s["value"]) for s in series if date.fromisoformat(s["day"]) >= cutoff]
    n = len(pts)
    if n < min_points:
        return None
    x0 = pts[0][0]
    xs = [(d - x0).days for d, _ in pts]
    ys = [v for _, v in pts]
    mx, my = sum(xs) / n, sum(ys) / n
    sxx = sum((x - mx) ** 2 for x in xs)
    b = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sxx if sxx else 0.0
    a = my - b * mx
    resid = [y - (a + b * x) for x, y in zip(xs, ys)]
    sd = sqrt(sum(r * r for r in resid) / (n - 2)) if n > 2 else 0.0
    sst = sum((y - my) ** 2 for y in ys)
    r2 = 1 - sum(r * r for r in resid) / sst if sst else 0.0
    base_x = (last - x0).days
    dates = [(last + timedelta(days=i + 1)).isoformat() for i in range(horizon)]
    fx = [base_x + i + 1 for i in range(horizon)]
    base = [max(0.0, a + b * x) for x in fx]
    # Prediction intervals include slope/intercept uncertainty (leverage), not just daily scatter.
    half = [1.96 * sd * sqrt(1 + 1 / n + ((x - mx) ** 2 / sxx if sxx else 0)) for x in fx]
    total = sum(base)
    var_total = sd ** 2 * (horizon + horizon ** 2 / n + ((sum(x - mx for x in fx)) ** 2 / sxx if sxx else 0))
    tband = 1.96 * sqrt(var_total)
    return {
        "method": "ols_linear_trend",
        "window_days": window_days,
        "n_points": n,
        "r2": round(r2, 3),
        "residual_sd": round(sd, 2),
        "slope_per_day": round(b, 4),
        "dates": dates,
        "base": [round(v, 2) for v in base],
        "low": [round(max(0.0, v - h), 2) for v, h in zip(base, half)],
        "high": [round(v + h, 2) for v, h in zip(base, half)],
        "total": {"base": round(total, 2), "low": round(max(0.0, total - tband), 2), "high": round(total + tband, 2)},
        "interval_note": "~95% prediction interval (daily scatter plus trend uncertainty); assumes the recent linear trend continues.",
    }


def differs_from_trailing(fc: dict, trailing_total: float) -> bool:
    """True only if the trailing total falls outside the forecast's ~95% interval, i.e. the
    predicted change is larger than normal day-to-day variation. Guards against acting on noise."""
    return trailing_total < fc["total"]["low"] or trailing_total > fc["total"]["high"]
