# ATHENA – autonomous advertising & business-intelligence decision engine

```
athena/backend/
  app/
    main.py            FastAPI app, CORS, startup migrations + legacy import
    config.py db.py security.py deps.py schemas.py
    seed.py            synthetic sample data (tagged source=sample_seed)
    legacy_import.py   preserves the 23-table MySQL dump as read-only legacy_* tables
    engine/
      metrics.py       normalisation/aggregation + Metric (value,type,formula,sources)
      forecast.py      OLS trend + prediction intervals + significance test
      decision.py      SCALE/HOLD/REDUCE/PAUSE/REVIEW, conflicts, confidence
      portfolio.py alerts.py insights.py
      scenario.py      custom inventory/ad-spend analysis (vertical slice)
      provenance.py    field/method catalogue -> References
    routers/           auth, data, analysis, references, imports
  migrations/001_init.sql
  tests/               31 tests (auth, isolation, rules, forecast, provenance, import)
  API_CONTRACT.md      frontend contract
```

## Run
```
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                   # optional; defaults work
uvicorn app.main:app --reload                          # http://127.0.0.1:8000/docs
pytest                                                 # 31 tests
```
Database `data/athena.db` is created and migrated on first start. Sign up (sample data is loaded by default), then open `/docs`.

## Frontend integration
Vite proxy: `server.proxy = { "/api": "http://127.0.0.1:8000", "/auth": "http://127.0.0.1:8000" }`, or use `credentials:"include"` with the CORS origins in `.env`. After login call `GET /api/command-center` for the three-mode screen.

## Key design decisions
- **Canonical DB: SQLite**, every business table scoped by `org_id` (company isolation). Sessions are server-side and revocable (only a token hash is stored); passwords use scrypt.
- **One source of truth for margin**: `products.margin_pct`. Contribution = revenue x margin - spend; break-even ROAS = 100 / margin.
- **Never fabricate**: missing values stay `null` and appear in `data_gaps`; user-typed values are `ASSUMED`; sample data is labelled synthetic.
- **Forecasts act only when significant**: a trend change must exceed the prediction interval before it influences a decision or alert.
- **Legacy MySQL dump is preserved, not blended**: its keys/scales do not link to campaign data (see `/api/references`).
- Secrets: configuration only through environment variables; `.env` and `*.db` are git-ignored.
